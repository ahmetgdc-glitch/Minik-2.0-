import React, { useState, useEffect } from "react";
import { Lock, Volume2, Settings2, Star, Check, Trash2 } from "lucide-react";
import { worlds, allItems, itemById } from "../data/content.js";
import { dispatch, setSettings, getStorageFailure } from "../progress/store.js";
import { difficultyFor } from "../progress/model.js";
import {
  refreshVoices,
  getVoices,
  subscribeVoices,
  speak,
} from "../audio/voice.js";
export default function Parents({ progress }) {
  const s = progress.settings,
    lang = s.lang,
    t = (de, tr) => (lang === "tr" ? tr : de);
  const [unlocked, setUnlocked] = useState(false),
    [code, setCode] = useState(""),
    [error, setError] = useState(false),
    [question] = useState(() => [
      7 + Math.floor(Math.random() * 5),
      4 + Math.floor(Math.random() * 5),
    ]),
    [voiceVersion, setVoiceVersion] = useState(0),
    [reset, setReset] = useState(false),
    [pin, setPin] = useState(s.pin);
  useEffect(() => {
    refreshVoices();
    return subscribeVoices(() => setVoiceVersion((v) => v + 1));
  }, []);
  function open(e) {
    e.preventDefault();
    if (code === (s.pin || String(question[0] + question[1]))) {
      setUnlocked(true);
      setError(false);
    } else {
      setError(true);
      setCode("");
    }
  }
  if (!unlocked)
    return (
      <section className="parent-gate">
        <div className="gate-icon">
          <Lock size={38} />
        </div>
        <h1>{t("Für die Großen", "Büyükler için")}</h1>
        <p>
          {s.pin
            ? t("Gib deine vierstellige PIN ein.", "Dört haneli PIN’ini gir.")
            : t(
                "Bitte einen Erwachsenen um Hilfe.",
                "Bir yetişkinden yardım iste.",
              )}
        </p>
        <form onSubmit={open}>
          <label htmlFor="parent-code">
            {s.pin ? "PIN" : `${question[0]} + ${question[1]} = ?`}
          </label>
          <input
            id="parent-code"
            autoComplete="off"
            type={s.pin ? "password" : "text"}
            inputMode="numeric"
            maxLength={4}
            value={code}
            onChange={(e) => setCode(e.target.value.replace(/\D/g, ""))}
          />
          {error && (
            <p className="form-error" role="alert">
              {t("Das stimmt noch nicht.", "Henüz doğru değil.")}
            </p>
          )}
          <button className="primary" type="submit">
            {t("Elternbereich öffnen", "Ebeveyn alanını aç")}
          </button>
        </form>
      </section>
    );
  const accuracy = progress.answers
    ? Math.round((progress.correct / progress.answers) * 100)
    : 0;
  const difficult = Object.entries(progress.mastery)
    .filter(([key, v]) => key.startsWith(lang + ":") && v.wrong > 0)
    .sort((a, b) => b[1].wrong - a[1].wrong)
    .slice(0, 8);
  function toggle(key, title, desc) {
    return (
      <label className="setting-toggle">
        <span>
          <b>{title}</b>
          <small>{desc}</small>
        </span>
        <input
          type="checkbox"
          checked={s[key]}
          onChange={(e) => setSettings({ [key]: e.target.checked })}
        />
      </label>
    );
  }
  return (
    <>
      <div className="section-heading">
        <div>
          <span className="eyebrow">MINIK 0.3</span>
          <h1>{t("Elternbereich", "Ebeveyn alanı")}</h1>
        </div>
        <Settings2 size={30} />
      </div>
      <div className="parent-stats">
        <div>
          <Star />
          <b>{progress.stars}</b>
          <span>{t("Sterne", "Yıldız")}</span>
        </div>
        <div>
          <Check />
          <b>{accuracy}%</b>
          <span>{t("Richtige Versuche", "Doğru denemeler")}</span>
        </div>
        <div>
          <b>{progress.sessions.filter((x) => x.completed).length}</b>
          <span>{t("Spielrunden beendet", "Tamamlanan oyun")}</span>
        </div>
        <div>
          <b>
            {
              Object.values(progress.mastery).filter((x) => x.independent >= 3)
                .length
            }
          </b>
          <span>{t("Sicher gelernt (DE/TR)", "Öğrenilen (DE/TR)")}</span>
        </div>
      </div>
      <section className="settings-panel">
        <h2>{t("Lernen & Spielen", "Öğrenme ve oyun")}</h2>
        <div className="settings-grid">
          <label>
            {t("Sprache", "Dil")}
            <select
              value={lang}
              onChange={(e) => setSettings({ lang: e.target.value })}
            >
              <option value="de">Deutsch</option>
              <option value="tr">Türkçe</option>
            </select>
          </label>
          <label>
            {t("Antwortmöglichkeiten", "Cevap seçenekleri")}
            <select
              value={s.options}
              disabled={s.adaptive}
              onChange={(e) => setSettings({ options: Number(e.target.value) })}
            >
              {[2, 4, 6].map((x) => (
                <option key={x} value={x}>
                  {x} {t("Bilder", "resim")}
                </option>
              ))}
            </select>
          </label>
        </div>
        {toggle(
          "adaptive",
          t("Schwierigkeit automatisch anpassen", "Zorluk otomatik ayarlansın"),
          t(
            "Beginnt mit 2 Bildern. Sichere Antworten führen zu 4 oder 6 Bildern.",
            "2 resimle başlar. Başarıya göre 4 veya 6 resme çıkar.",
          ),
        )}
        {toggle(
          "autoHelp",
          t("Mino hilft von selbst", "Mino kendiliğinden yardım etsin"),
          t(
            "Mino meldet sich nach Wartezeit. Bei Fehlern hilft er weiterhin.",
            "Bekleyince seslenir. Hatalarda yardım etmeye devam eder.",
          ),
        )}
        {toggle(
          "photos",
          t("Fotomotive bei Gefühlen", "Duygularda fotoğraf"),
          t(
            "Sechs KI-erzeugte Fotomotive erwachsener Personen.",
            "Yapay zekâyla üretilmiş altı yetişkin fotoğrafı.",
          ),
        )}
        {toggle(
          "reducedMotion",
          t("Ruhige Animationen", "Az hareket"),
          t(
            "Verringert schwebende und hüpfende Bewegungen.",
            "Süzülme ve zıplama hareketlerini azaltır.",
          ),
        )}
      </section>
      <section className="settings-panel">
        <h2>{t("Stimme & Töne", "Konuşma ve ses")}</h2>
        <p>
          {t(
            "MINIK nutzt die Stimmen deines Geräts ohne API-Schlüssel. Wie natürlich sie klingen und ob sie offline funktionieren, hängt von den installierten Stimmen ab.",
            "MINIK, API anahtarı olmadan cihazındaki sesleri kullanır. Doğallık ve çevrimdışı kullanım, yüklü seslere bağlıdır.",
          )}
        </p>
        {toggle(
          "audio",
          t("Sprachausgabe", "Sesli anlatım"),
          t(
            "Aufgaben und Wörter vorlesen.",
            "Görevleri ve kelimeleri seslendir.",
          ),
        )}
        {toggle(
          "sfx",
          t("Belohnungstöne", "Ödül sesleri"),
          t(
            "Kurze Töne für gelöste Aufgaben. Lern-Geräusche bleiben antippbar.",
            "Doğru görevlerde kısa sesler. Öğrenme sesleri dokunarak çalınabilir.",
          ),
        )}
        <div className="settings-grid">
          {["de", "tr"].map((l) => (
            <label key={l}>
              {l === "de"
                ? t("Deutsche Stimme", "Almanca ses")
                : t("Türkische Stimme", "Türkçe ses")}
              <select
                value={s.voices[l]}
                onChange={(e) =>
                  setSettings({ voices: { [l]: e.target.value } })
                }
              >
                <option value="">
                  {t("Beste verfügbare Stimme", "Mevcut en iyi ses")}
                </option>
                {getVoices(l).map((v) => (
                  <option key={v.voiceURI} value={v.voiceURI}>
                    {v.name}
                    {v.localService ? ` · ${t("lokal", "yerel")}` : ""}
                  </option>
                ))}
              </select>
              {!getVoices(l).length && (
                <small>
                  {t(
                    "Der Browser meldet noch keine passende Stimme.",
                    "Tarayıcı henüz uygun bir ses bildirmedi.",
                  )}
                </small>
              )}
            </label>
          ))}
          <label>
            {t("Sprechtempo", "Konuşma hızı")} · {s.rate.toFixed(2)}
            <input
              type="range"
              min="0.65"
              max="1.15"
              step="0.05"
              value={s.rate}
              onChange={(e) => setSettings({ rate: Number(e.target.value) })}
            />
          </label>
          <label>
            {t("Tonhöhe", "Ses perdesi")} · {s.pitch.toFixed(2)}
            <input
              type="range"
              min="0.8"
              max="1.3"
              step="0.05"
              value={s.pitch}
              onChange={(e) => setSettings({ pitch: Number(e.target.value) })}
            />
          </label>
        </div>
        <button
          className="secondary"
          onClick={() =>
            speak(
              t(
                "Hallo! Ich bin Mino. Wir entdecken heute die Tiere.",
                "Merhaba! Ben Mino. Bugün hayvanları keşfediyoruz.",
              ),
              lang,
              { ...s, audio: true },
            )
          }
        >
          <Volume2 size={20} />
          {t("Stimme anhören", "Sesi dinle")}
        </button>
      </section>
      <section className="settings-panel">
        <h2>{t("Fortschritt nach Lernwelt", "Dünyalara göre ilerleme")}</h2>
        <div className="table-scroll">
          <table>
            <thead>
              <tr>
                <th>{t("Lernwelt", "Dünya")}</th>
                <th>{t("Geübt", "Deneme")}</th>
                <th>{t("Richtig", "Doğru")}</th>
                <th>{t("Auswahl", "Seçenek")}</th>
              </tr>
            </thead>
            <tbody>
              {worlds.map((w) => {
                const p = progress.worlds[`${lang}:${w.id}`];
                return (
                  <tr key={w.id}>
                    <td>{w.labels[lang]}</td>
                    <td>{p?.answers || 0}</td>
                    <td>
                      {p?.answers
                        ? `${Math.round((p.correct / p.answers) * 100)}%`
                        : "–"}
                    </td>
                    <td>{difficultyFor(progress, w.id, lang)}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
        <p className="fine-print">
          {t(
            "Sicher gelernt: mindestens drei selbstständig gelöste Aufgaben pro Begriff und Sprache. Hilfe zählt als Übung. Die Trefferquote zählt auch Wiederholungsversuche.",
            "Öğrenildi: kavram ve dil başına en az üç bağımsız doğru görev. İpuçları alıştırma sayılır. Doğruluk oranına tekrar denemeleri de dâhildir.",
          )}
        </p>
      </section>
      <section className="settings-panel">
        <h2>{t("Noch einmal gemeinsam üben", "Birlikte tekrar çalışalım")}</h2>
        {difficult.length ? (
          <div className="difficult-words">
            {difficult.map(([key, v]) => {
              const item = itemById[key.slice(3)];
              return item ? (
                <button
                  key={key}
                  className="word-chip"
                  onClick={() => speak(item.labels[lang], lang, s)}
                >
                  <Volume2 size={16} />
                  {item.labels[lang]}
                  <small>
                    {v.wrong} {t("Fehlversuche", "hatalı deneme")}
                  </small>
                </button>
              ) : null;
            })}
          </div>
        ) : (
          <p>
            {t(
              "Hier erscheinen Begriffe, die noch Übung brauchen.",
              "Çalışılması gereken kavramlar burada görünür.",
            )}
          </p>
        )}
      </section>
      <section className="settings-panel">
        <h2>{t("Letzte Spielrunden", "Son oyunlar")}</h2>
        {progress.sessions.length ? (
          <ul className="session-list">
            {progress.sessions
              .slice(-8)
              .reverse()
              .map((x) => (
                <li key={x.id}>
                  <span>
                    {worlds.find((w) => w.id === x.worldId)?.labels[lang]} ·{" "}
                    {x.lang.toUpperCase()}
                    <small>
                      {new Date(x.started).toLocaleString(
                        lang === "de" ? "de-DE" : "tr-TR",
                      )}
                    </small>
                  </span>
                  <span>
                    {x.rounds}
                    <Star size={16} />
                    <small>
                      {x.completed
                        ? t("Beendet", "Tamamlandı")
                        : t("Unterbrochen", "Ara verildi")}{" "}
                      · {Math.max(1, Math.round(x.seconds / 60))} min
                    </small>
                  </span>
                </li>
              ))}
          </ul>
        ) : (
          <p>
            {t(
              "Noch keine Spielrunden gespeichert.",
              "Henüz kayıtlı oyun yok.",
            )}
          </p>
        )}
      </section>
      <section className="settings-panel">
        <h2>{t("Gerät & Schutz", "Cihaz ve koruma")}</h2>
        <p>
          {t(
            "Fortschritt bleibt in diesem Browser auf diesem Gerät. Es gibt keine Konten, Werbung oder Käufe. Beim Löschen der Browserdaten geht der Fortschritt verloren.",
            "İlerleme bu cihazın tarayıcısında saklanır. Hesap, reklam ve satın alma yoktur. Tarayıcı verileri silinirse ilerleme kaybolur.",
          )}
        </p>
        {getStorageFailure() && (
          <p role="alert" className="form-error">
            {t(
              "Speichern ist in diesem Browser nicht möglich. Fortschritt bleibt nur bis zum Schließen der App erhalten.",
              "Bu tarayıcıda kayıt yapılamıyor. İlerleme yalnızca uygulama açıkken korunur.",
            )}
          </p>
        )}
        <form
          className="pin-settings"
          onSubmit={(e) => {
            e.preventDefault();
            if (pin.length === 4 || pin === "") setSettings({ pin });
          }}
        >
          <label>
            {t(
              "Eigene vierstellige PIN (optional)",
              "Dört haneli PIN (isteğe bağlı)",
            )}
            <input
              type="password"
              inputMode="numeric"
              value={pin}
              maxLength={4}
              pattern="[0-9]{4}|"
              onChange={(e) => setPin(e.target.value.replace(/\D/g, ""))}
            />
          </label>
          <button className="secondary" type="submit">
            {t("PIN speichern", "PIN’i kaydet")}
          </button>
          {pin === s.pin && pin && <Check size={20} />}
        </form>
        <button className="danger-button" onClick={() => setReset(true)}>
          <Trash2 size={18} />
          {t("Lernfortschritt zurücksetzen", "İlerlemeyi sıfırla")}
        </button>
        <p className="fine-print">
          {worlds.length} {t("Welten", "dünya")} · {allItems.length}{" "}
          {t("Lernobjekte", "kavram")} · 12 {t("Spieltypen", "oyun türü")} ·
          MINIK 0.3.0
        </p>
      </section>
      {reset && (
        <div className="modal-scrim">
          <div className="pause-dialog" role="alertdialog" aria-modal="true">
            <h2>
              {t("Fortschritt zurücksetzen?", "İlerleme sıfırlansın mı?")}
            </h2>
            <p>
              {t(
                "Sterne, Schätze und Lernstatistik werden auf diesem Gerät gelöscht. Einstellungen bleiben erhalten.",
                "Bu cihazdaki yıldızlar, hazineler ve istatistikler silinir. Ayarlar korunur.",
              )}
            </p>
            <button
              className="primary"
              autoFocus
              onClick={() => setReset(false)}
            >
              {t("Behalten", "Koru")}
            </button>
            <button
              className="danger-button"
              onClick={() => {
                dispatch({ type: "reset" });
                setReset(false);
              }}
            >
              {t("Jetzt zurücksetzen", "Şimdi sıfırla")}
            </button>
          </div>
        </div>
      )}
    </>
  );
}
