import React, { useState, useEffect } from "react";
import { sample, shuffle } from "../utils/random.js";
import Visual, { Art } from "../components/Visual.jsx";
import { speak } from "../audio/voice.js";
import { useLesson } from "./shared.jsx";
export default function MemoryGame({
  items,
  difficulty,
  lang,
  settings,
  hint,
  paused,
  onReady,
  onWrong,
  onSolve,
}) {
  const [chosen] = useState(() =>
    sample(items, difficulty === 2 ? 3 : difficulty === 4 ? 4 : 6),
  );
  const [cards] = useState(() =>
    shuffle(
      chosen.flatMap((item) => [
        { id: item.id + "a", item },
        { id: item.id + "b", item },
      ]),
    ),
  );
  const [open, setOpen] = useState([]),
    [matched, setMatched] = useState([]);
  const text =
    lang === "tr" ? "Aynı iki resmi bul." : "Finde zwei gleiche Bilder.";
  useLesson(
    onReady,
    text,
    () => speak(text, lang, settings),
    chosen.map((i) => i.id),
    lang === "tr"
      ? "Kartları birlikte çevirelim."
      : "Wir drehen die Karten zusammen um.",
  );
  useEffect(() => {
    if (open.length !== 2 || paused) return;
    const [a, b] = open.map((id) => cards.find((c) => c.id === id)),
      ok = a.item.id === b.item.id;
    const timer = setTimeout(
      () => {
        if (ok) {
          const next = [...matched, a.item.id];
          setMatched(next);
          speak(a.item.labels[lang], lang, settings);
          if (next.length === chosen.length) onSolve(chosen.map((i) => i.id));
        } else onWrong([a.item.id, b.item.id]);
        setOpen([]);
      },
      ok ? 450 : 1100,
    );
    return () => clearTimeout(timer);
  }, [open, paused]);
  const helpPair = chosen.find((i) => !matched.includes(i.id))?.id;
  return (
    <>
      <div className="mini-status">
        {matched.length} / {chosen.length} {lang === "tr" ? "çift" : "Paare"}
      </div>
      <div className={`memory-grid cards-${cards.length}`}>
        {cards.map((card, index) => {
          const found = matched.includes(card.item.id),
            show =
              found ||
              open.includes(card.id) ||
              hint >= 3 ||
              (hint >= 2 && card.item.id === helpPair);
          return (
            <button
              className={`memory-card ${show ? "flipped" : ""} ${found ? "matched" : ""}`}
              key={card.id}
              disabled={found || open.length === 2}
              onClick={() => {
                if (!open.includes(card.id)) {
                  setOpen([...open, card.id]);
                  speak(card.item.labels[lang], lang, settings);
                }
              }}
              aria-label={
                show
                  ? card.item.labels[lang]
                  : lang === "tr"
                    ? `Kart ${index + 1}, çevir`
                    : `Karte ${index + 1}, umdrehen`
              }
            >
              {show ? (
                <Visual
                  item={card.item}
                  {...{ lang }}
                  photos={settings.photos}
                />
              ) : (
                <>
                  <Art name="spiral-shell" />
                  <span className="card-dot" />
                </>
              )}
            </button>
          );
        })}
      </div>
    </>
  );
}
