// Editorial content, reviewed German/Turkish labels. The fourth field is a Noto asset key.
// Groups are used for real category sorting, never inferred from the picture.
export const catalog = {
  animals: `lion|Löwe|Aslan|lion|wild
dog|Hund|Köpek|dog-face|pet
cat|Katze|Kedi|cat-face|pet
cow|Kuh|İnek|cow-face|farm
horse|Pferd|At|horse-face|farm
sheep|Schaf|Koyun|ewe|farm
tiger|Tiger|Kaplan|tiger-face|wild
monkey|Affe|Maymun|monkey-face|wild
rabbit|Kaninchen|Tavşan|rabbit-face|pet
bear|Bär|Ayı|bear|wild
elephant|Elefant|Fil|elephant|wild
giraffe|Giraffe|Zürafa|giraffe|wild
penguin|Pinguin|Penguen|penguin|wild
frog|Frosch|Kurbağa|frog|wild
fish|Fisch|Balık|tropical-fish|water
bird|Vogel|Kuş|bird|air
fox|Fuchs|Tilki|fox|wild
pig|Schwein|Domuz|pig-face|farm
duck|Ente|Ördek|duck|farm
chicken|Huhn|Tavuk|chicken|farm
turtle|Schildkröte|Kaplumbağa|turtle|water
butterfly|Schmetterling|Kelebek|butterfly|air
ladybug|Marienkäfer|Uğur böceği|lady-beetle|insect
bee|Biene|Arı|honeybee|insect
octopus|Oktopus|Ahtapot|octopus|water
dolphin|Delfin|Yunus|dolphin|water
shark|Hai|Köpek balığı|shark|water
whale|Wal|Balina|whale|water
snail|Schnecke|Salyangoz|snail|wild
hedgehog|Igel|Kirpi|hedgehog|wild`,
  food: `apple|Apfel|Elma|red-apple|fruit
banana|Banane|Muz|banana|fruit
pear|Birne|Armut|pear|fruit
orange|Orange|Portakal|tangerine|fruit
strawberry|Erdbeere|Çilek|strawberry|fruit
grapes|Trauben|Üzüm|grapes|fruit
watermelon|Wassermelone|Karpuz|watermelon|fruit
cherry|Kirschen|Kiraz|cherries|fruit
peach|Pfirsich|Şeftali|peach|fruit
lemon|Zitrone|Limon|lemon|fruit
pineapple|Ananas|Ananas|pineapple|fruit
kiwi|Kiwi|Kivi|kiwi-fruit|fruit
carrot|Karotte|Havuç|carrot|vegetable
tomato|Tomate|Domates|tomato|vegetable
broccoli|Brokkoli|Brokoli|broccoli|vegetable
cucumber|Gurke|Salatalık|cucumber|vegetable
corn|Mais|Mısır|ear-of-corn|vegetable
potato|Kartoffel|Patates|potato|vegetable
eggplant|Aubergine|Patlıcan|eggplant|vegetable
pepper|Paprika|Biber|bell-pepper|vegetable
bread|Brot|Ekmek|bread|meal
cheese|Käse|Peynir|cheese-wedge|meal
egg|Ei|Yumurta|egg|meal
milk|Milch|Süt|glass-of-milk|drink
rice|Reis|Pilav|cooked-rice|meal
soup|Suppe|Çorba|pot-of-food|meal
pasta|Nudeln|Makarna|spaghetti|meal
salad|Salat|Salata|green-salad|meal
honey|Honig|Bal|honey-pot|meal
juice|Saft|Meyve suyu|beverage-box|drink`,
  vehicles: `car|Auto|Araba|automobile|road
bus|Bus|Otobüs|bus|road
train|Zug|Tren|train|rail
bike|Fahrrad|Bisiklet|bicycle|road
truck|Lastwagen|Kamyon|delivery-truck|road
tractor|Traktor|Traktör|tractor|road
plane|Flugzeug|Uçak|airplane|air
ship|Schiff|Gemi|ship|water
canoe|Kanu|Kano|canoe|water
scooter|Roller|Scooter|kick-scooter|road
ambulance|Krankenwagen|Ambulans|ambulance|road
firetruck|Feuerwehrauto|İtfaiye aracı|fire-engine|road
helicopter|Hubschrauber|Helikopter|helicopter|air
rocket|Rakete|Roket|rocket|air
sailboat|Segelboot|Yelkenli|sailboat|water
motorbike|Motorrad|Motosiklet|motorcycle|road
tram|Straßenbahn|Tramvay|tram|rail
taxi|Taxi|Taksi|taxi|road
police|Polizeiauto|Polis arabası|police-car|road
speedboat|Motorboot|Sürat teknesi|speedboat|water`,
  clothes: `shirt|T-Shirt|Tişört|t-shirt|body
pants|Hose|Pantolon|jeans|body
dress|Kleid|Elbise|dress|body
shoe|Turnschuh|Spor ayakkabı|running-shoe|feet
socks|Socken|Çorap|socks|feet
hat|Kappe|Şapka|billed-cap|head
coat|Jacke|Ceket|coat|body
gloves|Handschuhe|Eldiven|gloves|hands
scarf|Schal|Atkı|scarf|head
glasses|Brille|Gözlük|glasses|head
boot|Stiefel|Çizme|womans-boot|feet
sandal|Sandale|Sandalet|womans-sandal|feet
bag|Handtasche|El çantası|handbag|accessory
backpack|Rucksack|Sırt çantası|backpack|accessory
crown|Krone|Taç|crown|head
helmet|Helm|Kask|rescue-workers-helmet|head
swimsuit|Badeanzug|Mayo|one-piece-swimsuit|body
umbrella|Regenschirm|Şemsiye|umbrella|accessory`,
  home: `bed|Bett|Yatak|bed|bedroom
chair|Stuhl|Sandalye|chair|living
lamp|Glühbirne|Ampul|light-bulb|living
door|Tür|Kapı|door|living
window|Fenster|Pencere|window|living
bath|Badewanne|Küvet|bathtub|bathroom
toilet|Toilette|Tuvalet|toilet|bathroom
key|Schlüssel|Anahtar|key|living
clock|Uhr|Saat|three-oclock|living
tv|Fernseher|Televizyon|television|living
phone|Telefon|Telefon|telephone|living
sofa|Sofa|Kanepe|couch-and-lamp|living
mirror|Spiegel|Ayna|mirror|bathroom
soap|Seife|Sabun|soap|bathroom
toothbrush|Zahnbürste|Diş fırçası|toothbrush|bathroom
shower|Dusche|Duş|shower|bathroom
broom|Besen|Süpürge|broom|living
basket|Korb|Sepet|basket|living
cup|Tasse|Fincan|hot-beverage|kitchen
spoon|Löffel|Kaşık|spoon|kitchen
plate|Teller mit Besteck|Çatal bıçaklı tabak|fork-and-knife-with-plate|kitchen
pan|Pfanne|Tava|cooking|kitchen
candle|Kerze|Mum|candle|living
bucket|Eimer|Kova|bucket|living`,
  nature: `sun|Sonne|Güneş|sun|sky
moon|Mond|Ay|crescent-moon|sky
star|Stern|Yıldız|star|sky
cloud|Wolke|Bulut|cloud|sky
rain|Regen|Yağmur|cloud-with-rain|weather
snow|Schneeflocke|Kar tanesi|snowflake|weather
tree|Baum|Ağaç|deciduous-tree|plant
flower|Blume|Çiçek|blossom|plant
mountain|Berg|Dağ|mountain|land
sea|Welle|Dalga|water-wave|water
fire|Feuer|Ateş|fire|land
leaf|Blatt|Yaprak|fallen-leaf|plant
rainbow|Regenbogen|Gökkuşağı|rainbow|sky
sunflower|Sonnenblume|Ayçiçeği|sunflower|plant
rose|Rose|Gül|rose|plant
cactus|Kaktus|Kaktüs|cactus|plant
palm|Palme|Palmiye|palm-tree|plant
mushroom|Pilz|Mantar|mushroom|land
volcano|Vulkan|Yanardağ|volcano|land
island|Insel|Ada|desert-island|land
snowman|Schneemann|Kardan adam|snowman-without-snow|weather
lightning|Blitz|Şimşek|high-voltage|weather
rock|Stein|Taş|rock|land
shell|Muschel|Deniz kabuğu|spiral-shell|water`,
  body: `eye|Auge|Göz|eye|head
ear|Ohr|Kulak|ear|head
nose|Nase|Burun|nose|head
mouth|Mund|Ağız|mouth|head
hand|Hand|El|raised-hand|limb
foot|Fuß|Ayak|foot|limb
arm|Arm|Kol|flexed-biceps|limb
leg|Bein|Bacak|leg|limb
tooth|Zahn|Diş|tooth|head
tongue|Zunge|Dil|tongue|head
brain|Gehirn|Beyin|brain|inside
heart|Herz|Kalp|anatomical-heart|inside`,
  feelings: `happy|Fröhlich|Mutlu|grinning-face-with-smiling-eyes|feeling
sad|Traurig|Üzgün|crying-face|feeling
surprised|Überrascht|Şaşkın|face-with-open-mouth|feeling
angry|Wütend|Kızgın|angry-face|feeling
tired|Müde|Yorgun|yawning-face|feeling
calm|Entspannt|Rahatlamış|relieved-face|feeling
afraid|Ängstlich|Korkmuş|fearful-face|feeling
laughing|Lachend|Gülen|grinning-squinting-face|feeling
thinking|Nachdenklich|Düşünceli|thinking-face|feeling
sick|Krank|Hasta|face-with-thermometer|feeling
sleepy|Schläfrig|Uykulu|sleeping-face|feeling
love|Verliebt|Âşık|smiling-face-with-hearts|feeling`,
  people: `baby|Baby|Bebek|baby|young
child|Kind|Çocuk|child|young
boy|Junge|Erkek çocuk|boy|young
girl|Mädchen|Kız çocuk|girl|young
man|Mann|Erkek|man|adult
woman|Frau|Kadın|woman|adult
grandpa|Älterer Mann|Yaşlı adam|old-man|adult
grandma|Ältere Frau|Yaşlı kadın|old-woman|adult
family|Familie|Aile|family|group
hug|Umarmung|Sarılma|people-hugging|group`,
  actions: `run|Laufen|Koşmak|person-running|movement
walk|Gehen|Yürümek|person-walking|movement
sleep|Schlafen|Uyumak|person-in-bed|rest
write|Schreiben|Yazmak|writing-hand|hands
sing|Singen|Şarkı söylemek|microphone|music
dance|Tanzen|Dans etmek|woman-dancing|movement
clap|Klatschen|Alkışlamak|clapping-hands|hands
swim|Schwimmen|Yüzmek|person-swimming|movement
cycle|Radfahren|Bisiklete binmek|person-biking|movement
climb|Klettern|Tırmanmak|person-climbing|movement
row|Rudern|Kürek çekmek|person-rowing-boat|movement
juggle|Jonglieren|Jonglörlük yapmak|person-juggling|hands
wave|Winken|El sallamak|waving-hand|hands
listen|Zuhören|Dinlemek|ear|rest
bathe|Baden|Banyo yapmak|person-taking-bath|rest
stretch|Dehnen|Esnemek|person-in-lotus-position|rest`,
  jobs: `doctor|Ärztin|Doktor|woman-health-worker|help
cook|Koch|Aşçı|man-cook|food
teacher|Lehrerin|Öğretmen|woman-teacher|help
police|Polizist|Polis|man-police-officer|help
firefighter|Feuerwehrfrau|İtfaiyeci|woman-firefighter|help
builder|Bauarbeiter|İnşaat işçisi|man-construction-worker|craft
farmer|Bäuerin|Çiftçi|woman-farmer|food
mechanic|Mechaniker|Tamirci|man-mechanic|craft
artist|Künstlerin|Sanatçı|woman-artist|art
pilot|Pilot|Pilot|man-pilot|travel
astronaut|Astronautin|Astronot|woman-astronaut|travel
scientist|Forscher|Bilim insanı|man-scientist|science
singer|Sängerin|Şarkıcı|woman-singer|art
judge|Richter|Hâkim|man-judge|help
office|Büroangestellte|Ofis çalışanı|woman-office-worker|work
technologist|Informatiker|Bilişim uzmanı|man-technologist|science`,
  toys: `teddy|Teddybär|Oyuncak ayı|teddy-bear|toy
ball|Fußball|Futbol topu|soccer-ball|ball
blocks|Bausteine|Yapı blokları|brick|toy
doll|Matroschka|Matruşka|nesting-dolls|toy
kite|Drachen|Uçurtma|kite|outdoor
yoyo|Jo-Jo|Yoyo|yo-yo|toy
puzzle|Puzzleteil|Yapboz parçası|puzzle-piece|toy
robot|Roboter|Robot|robot|toy
balloon|Luftballon|Balon|balloon|toy
dice|Würfel|Zar|game-die|toy
crayon|Wachsmalstift|Pastel boya|crayon|art
paint|Pinsel|Fırça|paintbrush|art
basketball|Basketball|Basketbol topu|basketball|ball
tennis|Tennisball|Tenis topu|tennis|ball`,
};
