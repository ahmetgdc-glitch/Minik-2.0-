import React from "react";
import { ArrowRight, Play, Star, ChevronRight } from "lucide-react";
import { worlds, worldById } from "../data/content.js";
import { localDay } from "../progress/model.js";
import { nextReward } from "../rewards/catalog.js";
import { Mino, Art } from "../components/Visual.jsx";
import WorldCard from "../components/WorldCard.jsx";
import { unlockAudio } from "../audio/sounds.js";
import { speak } from "../audio/voice.js";
export default function Home({ progress, onNavigate }) {
  const lang = progress.settings.lang,
    t = (de, tr) => (lang === "tr" ? tr : de),
    last = worldById[progress.lastWorld] || worlds[0],
    today = progress.daily.date === localDay() ? progress.daily.correct : 0,
    next = nextReward(progress);
  function start() {
    unlockAudio();
    speak(t("Los geht’s!", "Haydi başlayalım!"), lang, progress.settings);
    onNavigate(`/play/listen/${last.id}`);
  }
  return (
    <>
      <div className="welcome-heading">
        <div>
          <span className="eyebrow">
            {t(
              "Kleine Schritte. Große Entdeckungen.",
              "Küçük adımlar. Büyük keşifler.",
            )}
          </span>
          <h1>
            {t("Hallo, kleine Weltentdecker!", "Merhaba, küçük kâşifler!")}
          </h1>
        </div>
        <span className="level-badge">
          <Art name="star" /> {t("Level", "Seviye")}{" "}
          {Math.floor(progress.xp / 100) + 1}
        </span>
      </div>
      <div className="adventure-row">
        <section className="adventure-card">
          <div className="adventure-copy">
            <span className="adventure-tag">
              <span /> {t("Dein Abenteuer mit Mino", "Mino ile maceran")}
            </span>
            <h2>
              {t("Komm, wir\nentdecken was!", "Haydi, birlikte\nkeşfedelim!")}
            </h2>
            <p>
              {t(
                "Eine ganze Welt voller kleiner Wunder.",
                "Küçük harikalarla dolu kocaman bir dünya.",
              )}
            </p>
            <button className="primary" onClick={start}>
              <Play size={21} fill="currentColor" />
              {progress.correct
                ? t("Weiterspielen", "Devam et")
                : t("Los geht’s!", "Başlayalım!")}
            </button>
          </div>
          <div className="adventure-art">
            <span className="hero-halo" />
            <Mino />
            <Art className="floating-star one" name="star" />
            <Art className="floating-star two" name="star" />
            <span className="hello-bubble">{t("Hallo!", "Merhaba!")}</span>
          </div>
        </section>
        <button className="daily-card" onClick={() => onNavigate("/aquarium")}>
          <span className="eyebrow">
            {t("Deine Schatzmission", "Hazine görevin")}
          </span>
          <Art name="wrapped-gift" />
          <h3>
            {today >= 5
              ? t("Tagesziel geschafft!", "Günlük hedef tamam!")
              : t("Sammle 5 Sterne", "5 yıldız topla")}
          </h3>
          <div className="daily-stars">
            {Array.from({ length: 5 }, (_, i) => (
              <Star
                key={i}
                size={25}
                fill={i < today ? "currentColor" : "none"}
                className={i < today ? "collected" : ""}
              />
            ))}
          </div>
          <span>
            {Math.min(today, 5)} / 5 <ChevronRight size={16} />
          </span>
        </button>
      </div>
      <div className="section-heading">
        <div>
          <h2>{t("Wohin geht’s heute?", "Bugün nereye gidelim?")}</h2>
          <p>{t("Such dir eine Lernwelt aus.", "Bir öğrenme dünyası seç.")}</p>
        </div>
        <button className="text-button" onClick={() => onNavigate("/worlds")}>
          {t("Alle 16 Welten", "16 dünyanın hepsi")}
          <ArrowRight size={18} />
        </button>
      </div>
      <div className="world-grid">
        {worlds.slice(0, 8).map((w) => (
          <WorldCard
            key={w.id}
            world={w}
            lang={lang}
            progress={progress}
            onOpen={(w) => onNavigate(`/world/${w.id}`)}
          />
        ))}
      </div>
      <button className="playroom-banner" onClick={() => onNavigate("/games")}>
        <div className="playroom-images">
          <Art name="puzzle-piece" />
          <Art name="drum" />
          <Art name="crayon" />
        </div>
        <div>
          <h2>
            {t("Heute lieber ein Spiel?", "Bugün bir oyun oynayalım mı?")}
          </h2>
          <p>
            {t(
              "12 Spielideen warten auf dich.",
              "12 farklı oyun seni bekliyor.",
            )}
          </p>
        </div>
        <span className="circle-arrow">
          <ArrowRight />
        </span>
      </button>
    </>
  );
}
