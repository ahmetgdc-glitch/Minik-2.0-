import React, { useEffect } from "react";
import {
  Home as HomeIcon,
  Compass,
  Gamepad2,
  Waves,
  Lock,
  Volume2,
  VolumeX,
  ArrowLeft,
} from "lucide-react";
import {
  useProgress,
  setSettings,
  getStorageFailure,
} from "./progress/store.js";
import { useRoute, navigate } from "./app/router.js";
import { worlds, worldById } from "./data/content.js";
import { gameById } from "./games/registry.js";
import { stopSpeech } from "./audio/voice.js";
import { stopSounds } from "./audio/sounds.js";
import { Mino } from "./components/Visual.jsx";
import StarBar from "./components/StarBar.jsx";
import WorldCard from "./components/WorldCard.jsx";
import Home from "./app/Home.jsx";
import GamesScreen from "./app/GamesScreen.jsx";
import WorldScreen from "./worlds/WorldScreen.jsx";
import Aquarium from "./rewards/Aquarium.jsx";
import Parents from "./parent/Parents.jsx";
import GameSession from "./games/GameSession.jsx";
export default function App() {
  const progress = useProgress(),
    lang = progress.settings.lang,
    [route, arg, third, fourth] = useRoute(),
    t = (de, tr) => (lang === "tr" ? tr : de);
  useEffect(() => {
    document.documentElement.lang = lang;
    document.documentElement.dataset.motion = progress.settings.reducedMotion
      ? "reduced"
      : "full";
  }, [lang, progress.settings.reducedMotion]);
  const playing = route === "play" || route === "replay";
  function go(path) {
    if (path.startsWith("/replay/")) path = path + `/${Date.now()}`;
    navigate(path);
  }
  const game = gameById[arg],
    world = worldById[third],
    validGame =
      game && world && (game.allWorlds || game.worlds.includes(world.id));
  const nav = [
    ["/", HomeIcon, t("Start", "Ana sayfa")],
    ["/worlds", Compass, t("Lernwelten", "Dünyalar")],
    ["/games", Gamepad2, t("Spielkiste", "Oyunlar")],
    ["/aquarium", Waves, t("Aquarium", "Akvaryum")],
  ];
  function selected(path) {
    return path === "/"
      ? !route
      : path === "/worlds"
        ? ["worlds", "world"].includes(route)
        : path === `/${route}`;
  }
  if (playing && validGame)
    return (
      <main className="game-shell">
        <GameSession
          key={`${arg}-${third}-${fourth || route}-${lang}`}
          gameId={arg}
          worldId={third}
          onNavigate={go}
        />
      </main>
    );
  return (
    <div className="app-shell">
      <aside className="sidebar">
        <button
          className="brand"
          onClick={() => go("/")}
          aria-label={t("MINIK Startseite", "MINIK ana sayfa")}
        >
          <Mino />
          <span>
            minik<span className="brand-dot">.</span>
          </span>
        </button>
        <span className="sidebar-label">
          {t("DEINE LERNWELT", "SENİN ÖĞRENME DÜNYAN")}
        </span>
        <nav aria-label={t("Hauptnavigation", "Ana menü")}>
          {nav.map(([path, Icon, name]) => (
            <button
              key={path}
              aria-label={name}
              className={selected(path) ? "active" : ""}
              onClick={() => go(path)}
              aria-current={selected(path) ? "page" : undefined}
            >
              <Icon size={23} />
              <span>{name}</span>
            </button>
          ))}
        </nav>
        <div className="sidebar-mino">
          <Mino />
          <p>
            {t(
              "Kleine Schritte,\ngroße Freude.",
              "Küçük adımlar,\nbüyük mutluluk.",
            )}
          </p>
          <span>DEUTSCH · TÜRKÇE</span>
        </div>
        <button
          className={`parent-link ${route === "parents" ? "active" : ""}`}
          onClick={() => go("/parents")}
        >
          <Lock size={18} />
          {t("Elternbereich", "Ebeveyn alanı")}
        </button>
      </aside>
      <div className="main-shell">
        <header className="topbar">
          <button className="mobile-brand" onClick={() => go("/")}>
            <Mino />
            <b>minik.</b>
          </button>
          <div className="topbar-caption">
            {t(
              "Mit Neugier wird die Welt größer.",
              "Merak ettikçe dünya büyür.",
            )}
          </div>
          <div className="topbar-actions">
            <button
              className="audio-toggle"
              onClick={() => {
                setSettings({ audio: !progress.settings.audio });
                stopSpeech();
                stopSounds();
              }}
              aria-label={
                progress.settings.audio
                  ? t("Stimme ausschalten", "Konuşmayı kapat")
                  : t("Stimme einschalten", "Konuşmayı aç")
              }
            >
              {progress.settings.audio ? (
                <Volume2 size={22} />
              ) : (
                <VolumeX size={22} />
              )}
            </button>
            <button
              className="language-switch"
              onClick={() => {
                stopSpeech();
                setSettings({ lang: lang === "de" ? "tr" : "de" });
              }}
              aria-label={t("Zu Türkisch wechseln", "Almancaya geç")}
            >
              <span className={lang === "de" ? "chosen" : ""}>DE</span>
              <span className={lang === "tr" ? "chosen" : ""}>TR</span>
            </button>
            <StarBar
              stars={progress.stars}
              lang={lang}
              onClick={() => go("/aquarium")}
            />
            <button
              className="mobile-parents icon-button"
              onClick={() => go("/parents")}
              aria-label={t("Elternbereich", "Ebeveyn alanı")}
            >
              <Lock size={19} />
            </button>
          </div>
        </header>
        <main className="main-content">
          {getStorageFailure() && (
            <p role="status" className="storage-message">
              {t(
                "Fortschritt kann auf diesem Gerät gerade nicht gespeichert werden.",
                "İlerleme şu anda bu cihaza kaydedilemiyor.",
              )}
            </p>
          )}
          {!route ? (
            <Home progress={progress} onNavigate={go} />
          ) : route === "worlds" ? (
            <>
              <div className="section-heading">
                <div>
                  <span className="eyebrow">
                    {t("So viel zu entdecken", "Keşfedilecek çok şey var")}
                  </span>
                  <h1>{t("Deine Lernwelten", "Öğrenme dünyaların")}</h1>
                  <p>
                    {t(
                      "Jede Welt steckt voller neuer Entdeckungen.",
                      "Her dünya yeni keşiflerle dolu.",
                    )}
                  </p>
                </div>
              </div>
              <div className="world-grid all-worlds">
                {worlds.map((w) => (
                  <WorldCard
                    key={w.id}
                    world={w}
                    lang={lang}
                    progress={progress}
                    onOpen={(w) => go(`/world/${w.id}`)}
                  />
                ))}
              </div>
            </>
          ) : route === "world" && worldById[arg] ? (
            <WorldScreen
              key={arg}
              world={worldById[arg]}
              progress={progress}
              onNavigate={go}
            />
          ) : route === "games" ? (
            <GamesScreen progress={progress} onNavigate={go} />
          ) : route === "aquarium" ? (
            <Aquarium progress={progress} />
          ) : route === "parents" ? (
            <Parents progress={progress} />
          ) : (
            <div className="parent-gate">
              <Mino />
              <h1>
                {t(
                  "Hier geht’s zu deinen Welten",
                  "Dünyalarına buradan ulaşabilirsin",
                )}
              </h1>
              <button className="primary" onClick={() => go("/worlds")}>
                <ArrowLeft />
                {t("Lernwelten öffnen", "Dünyaları aç")}
              </button>
            </div>
          )}
        </main>
        <footer className="app-footer">
          <span>MINIK</span>
          <span>
            {t(
              "Mit Mino jeden Tag ein bisschen wachsen.",
              "Mino ile her gün biraz büyü.",
            )}
          </span>
        </footer>
      </div>
      <nav className="bottom-nav" aria-label={t("Hauptnavigation", "Ana menü")}>
        {nav.map(([path, Icon, name]) => (
          <button
            key={path}
            aria-label={name}
            className={selected(path) ? "active" : ""}
            onClick={() => go(path)}
            aria-current={selected(path) ? "page" : undefined}
          >
            <Icon size={24} />
            <span>{name}</span>
          </button>
        ))}
      </nav>
    </div>
  );
}
