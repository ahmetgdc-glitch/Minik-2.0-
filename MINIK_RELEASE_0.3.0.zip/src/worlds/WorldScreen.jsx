import React, { useState } from "react";
import { ArrowLeft, Play, Volume2, Star } from "lucide-react";
import { gamesForWorld } from "../games/registry.js";
import Visual, { Art } from "../components/Visual.jsx";
import { speak } from "../audio/voice.js";
import { unlockAudio } from "../audio/sounds.js";
export default function WorldScreen({ world, progress, onNavigate }) {
  const { lang } = progress.settings,
    [view, setView] = useState("games");
  const practiced = world.items.filter(
    (i) => (progress.mastery[`${lang}:${i.id}`]?.independent || 0) >= 3,
  ).length;
  return (
    <>
      <button className="back-link" onClick={() => onNavigate("/worlds")}>
        <ArrowLeft size={18} />
        {lang === "tr" ? "Tüm dünyalar" : "Alle Lernwelten"}
      </button>
      <section
        className="world-banner"
        style={{ "--world-color": world.color }}
      >
        <div>
          <span className="eyebrow">
            {lang === "tr"
              ? "Keşfet, oyna, öğren"
              : "Entdecken, spielen, lernen"}
          </span>
          <h1>{world.labels[lang]}</h1>
          <p>{world.description[lang]}</p>
          <span className="mastered-count">
            <Star size={18} />
            {practiced} / {world.items.length}{" "}
            {lang === "tr" ? "öğrenildi" : "sicher gelernt"}
          </span>
        </div>
        <Art name={world.asset} />
      </section>
      <div className="section-heading">
        <h2>
          {lang === "tr" ? "Nasıl oynayalım?" : "Wie möchtest du spielen?"}
        </h2>
        <div className="segment-control">
          <button
            className={view === "games" ? "active" : ""}
            onClick={() => setView("games")}
          >
            {lang === "tr" ? "Oyunlar" : "Spiele"}
          </button>
          <button
            className={view === "words" ? "active" : ""}
            onClick={() => setView("words")}
          >
            {lang === "tr" ? "Keşfet" : "Entdecken"}
          </button>
        </div>
      </div>
      {view === "games" ? (
        <div className="games-grid">
          {gamesForWorld(world.id).map((game) => (
            <button
              className="game-card"
              key={game.id}
              style={{ "--game-color": game.color }}
              onClick={() => {
                unlockAudio();
                onNavigate(`/play/${game.id}/${world.id}`);
              }}
            >
              <div className="game-card-art">
                <Art name={game.asset} />
                <span>
                  <Play size={19} fill="currentColor" />
                </span>
              </div>
              <h3>{game[lang]}</h3>
              <p>{game.description[lang]}</p>
            </button>
          ))}
        </div>
      ) : (
        <div className="discovery-grid">
          {world.items.map((item) => (
            <button
              className="discovery-card"
              key={item.id}
              onClick={() => speak(item.labels[lang], lang, progress.settings)}
            >
              <Visual
                item={item}
                lang={lang}
                photos={progress.settings.photos}
              />
              <b>{item.labels[lang]}</b>
              <span>
                <Volume2 size={17} />
                {item.labels[lang === "de" ? "tr" : "de"]}
              </span>
            </button>
          ))}
        </div>
      )}
    </>
  );
}
