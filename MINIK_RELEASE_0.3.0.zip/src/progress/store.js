import { useSyncExternalStore } from "react";
import {
  STORAGE_KEY,
  migrate,
  normalizeState,
  reduceProgress,
} from "./model.js";
let storage;
try {
  storage = window.localStorage;
} catch {}
let state = migrate(storage),
  storageFailed = false;
const listeners = new Set();
export const getState = () => state;
export const getStorageFailure = () => storageFailed;
export function dispatch(action) {
  state = reduceProgress(state, action);
  try {
    storage?.setItem(STORAGE_KEY, JSON.stringify(state));
    storageFailed = !storage;
  } catch {
    storageFailed = true;
  }
  listeners.forEach((fn) => fn());
  return state;
}
export const setSettings = (patch) => dispatch({ type: "settings", patch });
export function useProgress() {
  return useSyncExternalStore(
    (fn) => {
      listeners.add(fn);
      return () => listeners.delete(fn);
    },
    getState,
    getState,
  );
}
if (typeof window !== "undefined")
  window.addEventListener("storage", (e) => {
    if (e.key === STORAGE_KEY && e.newValue) {
      try {
        state = normalizeState(JSON.parse(e.newValue));
        listeners.forEach((fn) => fn());
      } catch {}
    }
  });
