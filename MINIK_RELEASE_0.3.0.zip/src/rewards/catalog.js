export const rewards = [
  {
    id: "shell",
    stars: 5,
    asset: "spiral-shell",
    de: "Glitzermuschel",
    tr: "Parlak deniz kabuğu",
  },
  {
    id: "coral",
    stars: 10,
    asset: "coral",
    de: "Bunte Koralle",
    tr: "Renkli mercan",
  },
  {
    id: "crown",
    stars: 20,
    asset: "crown",
    de: "Minos Krone",
    tr: "Mino’nun tacı",
  },
  {
    id: "castle",
    stars: 35,
    asset: "castle",
    de: "Unterwasserschloss",
    tr: "Su altı şatosu",
  },
  {
    id: "friend",
    stars: 50,
    asset: "blowfish",
    de: "Minos Freund",
    tr: "Mino’nun arkadaşı",
  },
  {
    id: "rainbow",
    stars: 80,
    asset: "rainbow",
    de: "Regenbogen",
    tr: "Gökkuşağı",
  },
  {
    id: "trophy",
    stars: 120,
    asset: "trophy",
    de: "Ozean-Pokal",
    tr: "Okyanus kupası",
  },
];
export const nextReward = (state) =>
  rewards.find((r) => !state.inventory.includes(r.id));
export const claimableRewards = (state) =>
  rewards.filter(
    (r) => r.stars <= state.stars && !state.inventory.includes(r.id),
  );
