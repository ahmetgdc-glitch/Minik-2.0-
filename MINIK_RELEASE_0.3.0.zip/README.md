# MINIK · Lernen mit Mino

**Release 0.3.0 · 9. September 2026**

Eine deutsch-türkische Kinder-Lernapp mit eigener Unterwasserwelt: große Bilder, zwölf unterschiedliche Minispiele, Mino als Helfer und ein wachsendes Aquarium. Release 0.2 und 0.3 sind umgesetzt; wichtige Teile der späteren Roadmap sind bereits integriert.

## Direkt loslegen

Zum Hochladen zuerst **[START_HIER.md](START_HIER.md)** lesen. Der Ordner `dist/` im Release-ZIP enthält die fertig gebaute App. `src/` und `public/` enthalten das vollständige, weiter bearbeitbare Projekt. Die `index.html` im Projektstamm ist der Vite-Einstieg und funktioniert auf GitHub Pages erst nach einem Build.

## Enthalten

- **16 Lernwelten, 278 Lernobjekte** mit deutschen und türkischen Bezeichnungen.
- **12 Spiele:** Hör & Tipp, Memory, Drag-and-Drop/Antippen, Sortieren, Zählen, Geräusche, Puzzle, Schatten, Was fehlt?, Muster, Zahlen nachfahren und Musikfolgen.
- Eigener Mino-Charakter, sehr große Bildkarten, Handy-Navigation, Tablet-Ansicht und Vollbild-Spieloberfläche.
- Inaktivitätshinweise, Hilfe nach Fehlern, Demonstration nach drei Fehlern, freundliches Feedback.
- Adaptive Schwierigkeit mit 2/4/6 Antworten; Eltern können eine feste Stufe wählen.
- Sterne, XP, Level, Tagesmission, sieben freischaltbare Schätze und ausstattbares Aquarium.
- Elternbereich mit Rechenzugang/optionaler PIN, Lernstatistik, schwierigen Begriffen, Sitzungen und Einstellungen.
- Kostenlose Geräte-Sprachausgabe, getrennte DE/TR-Stimmenauswahl, Tempo und Tonhöhe.
- 250 lokale Noto-Illustrationen einschließlich Bedien- und Belohnungsmotiven; sechs eigene KI-erzeugte Fotomotive erwachsener Personen für Gefühle.
- Lokale Fortschrittsspeicherung und Migration des bisherigen Sternestands; kompakter Offline-Kern und GitHub-Pages-Workflow.

## Entwicklung

Voraussetzung: Node.js ab 22.12; CI verwendet Node 24.

```bash
npm ci
npm run dev
```

Nach Änderungen:

```bash
npm test
npm run build
npm run verify:build
```

`npm run assets` erzeugt die verwendeten SVGs und das Contentmanifest erneut aus dem angepinnten Noto-Paket. `npm run preview` zeigt den Produktionsbuild lokal.

## Umfang und Grenzen

Alle sichtbaren Welten haben eigene Inhalte und passende Spiele. Zahlenlernen umfasst 1–20, Nachfahren aktuell 1–5. Die Geräusche werden lokal mit Web Audio synthetisiert; es sind keine aufgenommenen Tierstimmen. Fotomotive sind synthetisch und stellen keine realen Personen dar.

Die Sprachqualität und Offline-Verfügbarkeit der Stimme hängen von den auf dem Gerät installierten Systemstimmen ab. Es gibt keinen kostenpflichtigen Sprachdienst und keinen API-Schlüssel im Client. Für weitere Fotowelten, Geschichten, Buchstaben, Aussprachetraining und echte Tonaufnahmen siehe [Roadmap](docs/ROADMAP.md).

Die kleinen optimierten Dateien sind beabsichtigt: Umfang entsteht durch Spiele und Inhalte, nicht durch künstlich aufgeblähte Downloads. Große Medienpakete können später getrennt ergänzt werden.

## Prüfung und Weiterarbeit

- [QA-Protokoll](docs/QA_CHECKLIST.md): automatisierte Tests, Browserdurchläufe und offene Hardwaretests.
- [Technik](docs/TECH_SPEC.md): Module, Fortschritt, Audio und Offline-Strategie.
- [Content](docs/CONTENT_PLAN.md): alle Welten und Erweiterungsschritte.
- [Übergabe](docs/HANDOFF_SUMMARY.md): aktueller Stand und nächster sinnvoller Ausbau.
- [Änderungen](CHANGELOG.md).
- Fremdasset-Lizenzen und Herkunft: `public/licenses/NOTICE.txt`.
