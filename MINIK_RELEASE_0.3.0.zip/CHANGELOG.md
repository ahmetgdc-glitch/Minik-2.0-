# Changelog

## 0.3.0 — 2026-09-09

### Release 0.2 vollständig integriert

- Sechs getrennte Kernspiele: Hören, Memory, echtes Pointer-Zuordnen mit Tippalternative, Sortieren, Zählen und synthetisierte Alltagsgeräusche.
- Gemeinsame Spielsteuerung für Runden, Pause, Wiederholung, Hilfen und Belohnungen.

### Release 0.3 vollständig integriert

- 16 Welten und 278 vollständige DE/TR-Lernobjekte statt sechs Tierbegriffen.
- Lokale, lizenzierte SVG-Assetpipeline und versioniertes Contentmanifest.
- Foto-Variantenmodell mit Herkunftsdaten; sechs KI-generierte Erwachsenen-Gefühlsmotive.
- Neuer eigener Mino und große responsive App-Oberfläche.

### Vorgezogene Erweiterungen

- Sechs zusätzliche Spiele: Puzzle, Schatten, Merkspiel, Muster, Zahlenpfade und Musikfolge.
- Mehrstufige Mino-Hilfe, anpassbare Schwierigkeit, eigenständige DE/TR-Lernstatistik.
- XP, Level, Sterne, Tagesmission, sieben Schätze und Aquariumgestaltung.
- Elternbereich mit optionaler PIN, Sprach- und Audioeinstellungen, schwierigen Begriffen und Sitzungen.
- Sofortige lokale Speicherung pro Antwort; alte Sterne und Sprache werden übernommen.
- Produktions-Service-Worker mit komplettem kompaktem Kern und Cache-Trennung pro Installationspfad.
- GitHub Actions, 21 Content-/Fortschrittstests und Offline-Buildprüfung für Root- und Repository-Pfade.
- Browserprüfungen aller zwölf Mechaniken; responsive Prüfung bei 320, 393 und 768 Pixeln sowie Desktop.

### Behobene Probleme

- Welten öffnen nicht mehr alle dasselbe Tierquiz.
- Keine mehrfachen Sterne durch wiederholte Klicks; Fehlversuche geben keine Sterne.
- Hilfestellung wird nicht als selbstständige Begriffsbeherrschung gezählt.
- Wiederholte Fehlversuche senken die nächste Schwierigkeitsstufe auch ohne anschließende richtige Antwort.
- Puzzle wird nur für tatsächlich geeignete Bildwelten angeboten.
- Unsichtbare Antwortduplikate durch gleiche Bildmotive werden vermieden.
- Tablet-Symbolnavigation erhält zugängliche Namen; Pausendialog sperrt Hintergrundbedienung.

## 0.1 — übernommener Ausgangsstand

React/Vite-Starter, sechs Tierbegriffe, eine Auswahlrunde, einfache Sterne und System-TTS.
