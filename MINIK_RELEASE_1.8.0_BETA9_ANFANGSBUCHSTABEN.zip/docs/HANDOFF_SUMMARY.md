# MINIK — Übergabe nach Release 0.3.0

Stand: 9. September 2026. Der ursprüngliche Nutzerauftrag steht unverändert in `MASTER_PROMPT_FOR_WORK.md`.

## Was fertig ist

Release 0.2 und 0.3 sind vollständig umgesetzt. Die App hat zwölf unterschiedliche Spiele, 16 echte Lernwelten und 278 DE/TR-Items. Ein großer eigener Mino, lokale Illustrationen und sechs KI-generierte Fotomotive ersetzen die kleine Starterdarstellung. Rewards, Hilfe, Elternbereich und Offline-Kern wurden bereits aus späteren Releases vorgezogen.

## Zuerst ausführen

```bash
npm ci
npm test
npm run build
npm run verify:build
```

Der letzte Release hat 21 bestandene Tests, einen erfolgreichen Produktionsbuild und eine bestandene Offline-Vertragsprüfung mit echten Builddateien für `/` und `/Minik-2.0-/`. Alle zwölf Spielmechaniken wurden über die Browseroberfläche mindestens eine Aufgabe lang erfolgreich gespielt. Eine komplette Hörrunde, Reward-Abholung und Fortschritt nach Reload wurden zusätzlich geprüft. Einzelheiten und verbleibende Hardwaretests: `QA_CHECKLIST.md`.

## Architektur

- `src/App.jsx`, `app/`: Hash-Routing, Start, Spielauswahl. Spiel-/Weltkombinationen werden validiert.
- `src/games/`: zwölf getrennte Spiele; `GameSession.jsx` verwaltet Session, Timer, Hilfe und Sternvergabe.
- `src/data/worlds/catalog.js`, `data/content.js`: redaktioneller Inhalt, DE/TR, Darstellungsvarianten, Metadaten.
- `src/components/Visual.jsx`: Illustrationen, Zahlen, Formen, Farben, Fotos und Mino.
- `src/progress/model.js`: reiner Reducer, Speicherungsschema und Migration; `store.js`: Browseranbindung.
- `src/audio/`: Geräte-TTS und Web-Audio-Geräusche. Kein externer Dienst aktiv.
- `src/rewards/`, `src/parent/`: Aquarium und Elternstatistik.
- `scripts/`: Assets erzeugen/prüfen, Service Worker bauen, Build und Offline-Fallback prüfen.

## Wichtige Regeln für die Weiterarbeit

- Nicht wieder zu einem einzigen generischen Quiz oder kleinen Emoji-Karten zurückgehen.
- Für jede neue Welt sinnvolle Spiele und unverwechselbare Motive sicherstellen.
- Nach jeder größeren Änderung `npm run build`; vor Übergabe zusätzlich Tests und `verify:build`.
- Stabile Item-IDs und `minik_progress_v3` erhalten bzw. bei Änderungen gezielt migrieren.
- Sterne sind dauerhaft verdient, keine auszugebende Währung. Schätze kosten keine Sterne.
- Beherrschung: drei selbstständige richtige Aufgaben pro Begriff und Sprache. Hilfe zählt als Übung.
- Nach drei Fehlern kommt eine Demonstration und eine neue Aufgabe, ohne Belohnungsstern.
- Schwierigkeitsanpassung gilt ab der nächsten Spielsession; 2/4/6 Antworten oder vergleichbare Spielkomplexität.
- Alle 16 Welten sind derzeit offen. Neue Weltfreischaltungen nicht rückwirkend sperren.
- Fotos sind synthetische Erwachsene, keine dokumentarischen Aufnahmen realer Menschen.
- Keine vertraulichen Schlüssel oder Cloud-TTS-URLs ohne sichere Backendarchitektur hinzufügen.

## Noch nicht als erledigt behaupten

Keine Veröffentlichung im echten GitHub-Repository durchgeführt. GitHub-fähiger Workflow und Build liegen bereit. Browserprüfung erfolgte in Chromium, einschließlich Handy-/Tablet-Breiten; kein physisches iPhone/iPad und keine hörbare Qualitätsprüfung seiner DE/TR-Stimmen. Offline-Cache/Navigation wurde automatisiert simuliert; Safari-Flugmodus und Installation müssen auf Gerät geprüft werden.

## Nächster sinnvoller Ausbau

1. Auf realem iPhone/iPad veröffentlichte App und installierte Stimmen hören/testen.
2. Pädagogische DE/TR-Redaktion mit Eltern bzw. Fachperson; synthetisierte Geräusche durch eindeutige eigene/lizenzierte Aufnahmen erweitern.
3. Neue Inhalte für Körper, Familie, Berufe und Alltag als eigene Fotopakete.
4. Geschichten, soziale Abläufe, Buchstaben und Gegensätze als neue Mechaniken/Welten, danach auf 25 Welten und 500+ Begriffe skalieren.
5. Große Medienpakete optional mit Versionsmanifest und Downloadstatus laden; kompakten Kern erhalten.

## GitHub und Paket

`START_HIER.md` ist die einfache Nutzeranleitung. Quellcode und fertiges `dist/` liegen im Release-ZIP. Ein normales Checkout erzeugt `dist/` mit dem Build. Das Projekt ist kein bloßer Handoff-Starter mehr. `docs/legacy_single_file_prototype.html` bleibt ausschließlich als unverändertes Archiv des ursprünglichen Prototyps enthalten und wird nicht gebaut oder veröffentlicht.
