# GitHub Pages · Release 0.3.0

Nutzeranleitung: `../START_HIER.md`.

Der Workflow `.github/workflows/deploy.yml` baut auf `main`, `master` oder manuelle Anforderung mit Node 24. Gates: `npm ci`, `npm test`, `npm run build`, `npm run verify:build`. Danach werden `dist/` als Pages-Artefakt hochgeladen und über das Environment `github-pages` veröffentlicht.

Im Repository muss unter Settings → Pages „GitHub Actions“ als Quelle ausgewählt sein. Vorhandene alternative Deploy-Workflows beim Übernehmen prüfen, damit nicht zwei unterschiedliche Builds dieselbe Site veröffentlichen.

Vite verwendet `base: './'`; Hash-Routing benötigt keinen Server-Fallback. Relative Assets, Manifest und Service-Worker-Scope funktionieren unter einem Repository-Pfad wie `/Minik-2.0-/`. `verify:build` prüft sowohl diesen Fall als auch die Domainwurzel.

Alternativ alle Dateien **aus** `dist/` in einen statischen Pages-Branch übernehmen und „Deploy from a branch“ einstellen. Die Projektstamm-`index.html` nicht allein veröffentlichen.

Ein alter Service Worker kann eine bereits geöffnete Appversion weiter bedienen. Nach erfolgreichem Update alle App-Tabs schließen und neu öffnen. Zum Debuggen eines hartnäckigen Caches Browser-Sitedaten nur bewusst löschen: dabei gehen auch die lokal gespeicherten Sterne verloren.

Der Workflow liegt fertig vor; Ausführung und URL im echten Benutzerrepository sind noch nicht geprüft.
