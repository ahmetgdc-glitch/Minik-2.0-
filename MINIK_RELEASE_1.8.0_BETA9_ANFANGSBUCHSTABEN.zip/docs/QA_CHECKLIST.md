# Release-QA 0.3.0

Stand: 2026-09-09. „Bestanden“ bedeutet die unten beschriebene Prüfung, nicht einen Test auf jedem Gerät.

## Automatisiert

- [x] Frische Installation mit `npm ci`, danach Produktionsbuild und alle Gates erneut erfolgreich.

- [x] Produktionsbuild nach größeren Implementierungsblöcken ausgeführt; zwischenzeitliche Buildfehler behoben.
- [x] 21 Node-Tests: DE/TR-Inhalte, 16 Welten, 278 IDs, lokale Assets, eindeutige 2/4/6-Antworten, Zahlen und Geräusche.
- [x] Sterne-Deduplizierung, keine Sterne für Fehler, sprachgetrennte Beherrschung, Hilfe, adaptive/feste Stufen, Tageswechsel, Rewards, Migration, Speicherung und Reset.
- [x] Regression: Nur-Fehlversuche senken die Schwierigkeit ebenfalls.
- [x] `verify:build`: alle Shellverweise vorhanden, Installation/Offline-Fallback mit echten Builddateien bei `/` und `/Minik-2.0-/`, Cacheisolation pro Installationspfad.

## Über die tatsächliche Browseroberfläche gespielt

| Spiel | Prüfung | Ergebnis |
| --- | --- | --- |
| Hör & Tipp | Zwei Fehler, Mino-Hervorhebung, richtige Antwort; außerdem komplette Sechserrunde | Bestanden |
| Memory | Hilfepaar sichtbar, Karten aufdecken, alle drei Paare eines Bretts | Bestanden |
| Zuordnen | Echter Zeiger-Drag und alternative Quell-/Zielklicks, Brett abgeschlossen | Bestanden |
| Sortieren | Schiff dem Fahrzeugkorb zugeordnet | Bestanden |
| Zählen | Drei Delfine in anderer Reihenfolge antippen und passende Zahl wählen | Bestanden |
| Geräusche | Wiederholungsbedienung, Mino-Hilfe, Geräusch zuordnen | Bestanden |
| Puzzle | Vertauschte Bildquadranten zum vollständigen Motiv zusammensetzen | Bestanden |
| Schatten | Silhouette dem richtigen Tierbild zuordnen | Bestanden |
| Was fehlt? | Drei Lebensmittel merken, versteckten Brokkoli finden | Bestanden |
| Muster | Straßenbahn/Segelboot-Folge ergänzen | Bestanden |
| Nachfahren | Zeiger entlang des sichtbaren Viererpfades; Fortschritt und Stern | Bestanden |
| Musik | Wiedergabephase sperrt Tasten; dreiteilige Folge mit visueller Hilfe nachspielen, auch TR im Produktionsbuild | Bestanden |

Die Geräuschprüfung bestätigt UI, Wiedergabestatus und Antwortlogik. Eine menschliche Hörabnahme der Klangunterscheidbarkeit bleibt sinnvoll.

## Fortschritt und Darstellung

- [x] Sieben verdiente Sterne nach Reload erhalten; Muschel bei fünf Sternen abgeholt, ausgerüstet und nach Reload erhalten.
- [x] Eltern-Rechenzugang, echte Antwortquote/Fehlerdaten/Sitzung und Einstellungen kontrolliert.
- [x] Vollständige 16-Welten-Auswahl und unterschiedliche Welt-/Spielinhalte.
- [x] DE/TR-Oberfläche und türkische Spielantwort/Belohnung/Pause.
- [x] Fotoentdeckung in der türkischen Gefühlswelt visuell geprüft.
- [x] Produktionsbuild in 393 × 852 und 320 × 740 CSS-Viewports: große Bilder, Antwortflächen, Mino und Bedienelemente sichtbar.
- [x] 768-Pixel-Tablet und Desktop visuell geprüft; namenlose Tablet-Symbolbuttons korrigiert.
- [x] Kein beobachteter MINIK-Laufzeitfehler. Die Prüfumgebung meldete separat Fehler ihrer Browsererweiterung.
- [x] Lokal gebündelte Assets und Lizenznachweise; keine Frontend-API-Schlüssel.

## Verbleibende Geräte-/Veröffentlichungsprüfung

- [ ] Tatsächliches iPhone/iPad: Touchgefühl, Safari, Home-Bildschirm und Querformat.
- [ ] Deutsche und türkische installierte Stimmen anhören; Tempo einstellen; rasches Wiederholen ohne überlappende Sprache kontrollieren.
- [ ] HTTPS-App einmal online laden, schließen und im Flugmodus neu öffnen; lokale Stimmen separat prüfen.
- [ ] GitHub-Workflow im tatsächlichen Repository ausführen und veröffentlichte Adresse prüfen.
- [ ] Begriffs- und Fotointerpretation mit einer deutsch-/türkischsprachigen pädagogischen Fachperson durchsehen.

Es wurde kein GitHub-Deployment und kein physischer iPhone-Hörtest vorgetäuscht.
