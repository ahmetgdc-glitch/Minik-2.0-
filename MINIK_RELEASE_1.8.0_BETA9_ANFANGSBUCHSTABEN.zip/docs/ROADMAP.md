# MINIK Roadmap

Stand 0.3.0 · 2026-09-09. Erledigte spätere Aufgaben wurden vorgezogen; die Versionsnummer behauptet keine fertige 1.0.

## Release 0.1 — Fundament

- [x] React/Vite, DE/TR, Mino und Sterne
- [x] Sauberes Hash-Routing und echte Welt-/Spielnavigation
- [x] Modularer Progress Store und alte Datenmigration
- [x] Voice Settings

## Release 0.2 — sechs echte Spiele · abgeschlossen

- [x] Hör & Tipp
- [x] Memory
- [x] Drag-and-Drop und Tippalternative
- [x] Sortieren
- [x] Zählen
- [x] Alltagsgeräusche erkennen

## Release 0.3 — Content · abgeschlossen

- [x] Mindestens 12 Welten: **25 vorhanden**
- [x] 250+ Items: **503 vorhanden**, jeweils DE/TR
- [x] Foto-Contentmodell und sechs Gefühls-Fotomotive
- [x] Lokale Illustrationspipeline mit Lizenz- und Herkunftsdaten

## Release 0.4 — Mino + adaptives Lernen · vorgezogen

- [x] Inaktivitätshinweise nach 6/11 Sekunden
- [x] Mehrstufige Hilfe, Zielhervorhebung, Demonstration
- [x] Fehler-/Begriffsstatistik pro Sprache
- [x] Automatische Schwierigkeit und manuelle 2/4/6-Auswahl
- [x] Verschiedene Lobtexte
- [ ] Pädagogische Langzeitprüfung und differenziertere Wiederholungsplanung

## Release 0.5 — Belohnungen · Kern vorgezogen

- [x] XP, Level und Sterne
- [x] Schatzfreischaltung an sieben Meilensteinen
- [x] Dekorierbares Aquarium und Mino-Krone
- [x] Tagesmission
- [ ] Weitere Mino-Outfits
- [ ] Zusätzliche freischaltbare Welten und größere Questketten

## Release 0.6 — Elternbereich · vorgezogen

- [x] Rechenzugang und optionale vierstellige PIN
- [x] Lernstatistik, schwierige Begriffe und Sitzungen
- [x] Stimme, Sprache, Tempo, Tonhöhe
- [x] Schwierigkeit, Antwortanzahl, Audio und Bewegungsreduktion
- [x] Fortschrittsexport/-import für Gerätewechsel

## Release 0.7 — 12+ Spiele · teilweise vorgezogen

- [x] Puzzle
- [x] Farben und Formen als eigene Lernwelten mit mehreren Spielen
- [x] Zahlen nachfahren (1–5)
- [x] Muster, Schatten und Merkspiel
- [x] Gefühle lernen mit Fotovarianten
- [x] Musikfolge/Rhythmus
- [x] Geschichten mit Fragen
- [x] Buchstaben nachfahren und Anfangsbuchstaben
- [ ] Nachsprechen/Aussprache
- [x] Malen
- [ ] Unterschiede, Gegensätze und soziale Bildsequenzen

## Release 1.0

- [x] 25 Welten
- [x] 500+ Items
- [x] 15+ unterschiedliche Spielmechaniken
- [x] Kompakter Offline-Kern
- [x] Responsive Browserprüfung für schmale Handys, Tablet und Desktop
- [ ] Physische iPhone-/iPad-Prüfung inklusive Stimmen und Flugmodus
- [x] GitHub-Pages-Build und Deploy-Workflow vorbereitet
- [ ] Im tatsächlichen Repository veröffentlichen und veröffentlichte URL prüfen
- [ ] Optionale große Medienpakete mit eigenem Downloadmanagement
