# 1.7.0 Beta 8 — Offline-/Gerätehärtung

- Live-Erkennung für Online/Offline-Wechsel ergänzt; MINIK zeigt kindgerecht an, dass gespeicherte Inhalte offline weiterlaufen.
- Netzwerkstatus reagiert ohne Neuladen auf iPhone/iPad-Verbindungswechsel.
- Regressionstest für Offline-Hook, Event-Cleanup und UI-Hinweis ergänzt.
- Vollständige bestehende Test-, Content- und Offline-Build-Prüfung erneut ausgeführt.

# 1.6.0 Beta 7 — Stabilität & iPhone-Spielbetrieb

- Neue globale Crash-Recovery: Ein einzelner Renderfehler lässt die App nicht mehr in einem weißen Bildschirm hängen; Lernfortschritt bleibt erhalten.
- Kinder können nach einem UI-Fehler direkt zur Startseite zurück oder die App neu laden.
- Während aktiver Spiele fordert MINIK, wo vom Gerät unterstützt, einen Screen-Wake-Lock an, damit iPhone/iPad/Android während einer Runde nicht unnötig schlafen gehen.
- Wake-Lock wird beim Verlassen des Spiels sauber freigegeben und nach Rückkehr aus dem Hintergrund erneut angefordert.
- App-Metadaten und Beschreibung auf den tatsächlichen Umfang von 25 Welten und 500+ Lernobjekten aktualisiert.

## 1.5.0 Beta 6 — 25 Lernwelten, 500+ Begriffe und Buchstabenmotorik

- Release-Ziel erreicht: **25 Lernwelten** und **503 deutsch/türkische Lernobjekte**.
- Neun neue Welten: Schule, Sport, Musik, Weltraum, Wetter, Mein Tag, Sicherheit, Orte und Buchstaben.
- Neuer 17. Spieltyp **Buchstaben nachfahren** mit großen Fingerpfaden für frühe Schreibmotorik.
- Content-Gates verschärft: Tests verlangen jetzt mindestens 25 Welten, 500 Items und 17 Spieltypen.
- Content-Manifest auf den vollständigen neuen Lernkatalog aktualisiert.
- Produktionsbuild bleibt in dieser isolierten Umgebung durch das fehlende lokale Vite-Binary blockiert; Logik- und Inhaltsprüfungen laufen unabhängig davon.

# MINIK Changelog

## 1.4.0 Beta 5 — Geschichten, Familien-Backup und QA-Härtung

- Neuer 16. Spieltyp **„Minos Geschichte“**: dreiteilige DE/TR-Mini-Geschichten mit visueller Reihenfolge und einfacher Hör-/Merkfrage.
- Vollständiger **Familien-Backup/Restore** im geschützten Elternbereich. Alle Kinderprofile, Sterne, Lernstände, Belohnungen und Einstellungen können als lokale JSON-Datei gesichert und auf einem anderen Gerät wiederhergestellt werden.
- Backup-Import validiert Format, Profilanzahl, IDs und normalisiert beschädigte Fortschrittsdaten vor der Übernahme.
- Bestehenden UI-Fehler behoben: doppelte Sterne-Beschriftung im Elternbereich entfernt.
- Veraltete fest codierte Versions- und Spieltypangaben entfernt; die Anzeige nutzt jetzt den echten Spielkatalog.
- QA erweitert: lokale Welt- und Spiel-Assets werden automatisch auf Existenz geprüft. Dadurch wurde ein zunächst ungültiges Story-Asset sofort erkannt und korrigiert.
- Automatische Tests: **44/44 bestanden**. Content-Gate: **16 Welten · 278 DE/TR-Lernobjekte · 16 Spieltypen**.
- Produktionsbuild bleibt in dieser isolierten Arbeitsumgebung blockiert, weil die npm-Paketdateien für Vite nicht lokal gecacht sind; die Quellcode-/Content-/Logiktests laufen vollständig.

# 1.3.0-beta.4 — Lernwoche & flüssiger Spielpfad

- Elternbereich zeigt jetzt eine echte 7-Tage-Lernwoche mit aktiven Minuten, beendeten Runden, Trefferquote, stärkster Lernwelt und Tagesaktivität.
- Spielzeit zählt nur aktive Sekunden; Pausen und ausgeblendete Tabs werden nicht als Lernzeit gewertet.
- Nach einer abgeschlossenen Runde schlägt Mino direkt die nächste adaptive Aktivität vor, statt den Lernfluss im Belohnungsmenü zu beenden.
- Aquarium bleibt vom Abschlussbildschirm aus erreichbar, steht aber nicht mehr im Weg des nächsten Lernschritts.
- Doppelten Trefferquoten-Wert im Elternbereich und doppeltes `aria-label` am Wiederholen-Knopf behoben.
- Neue Analytics-Regressionstests für 7-Tage-Auswertung und stärkste Lernwelt.


## 1.2.0-beta.3 – Intelligente Wiederholung über mehrere Tage

- Neues Spaced-Repetition-System: Begriffe bekommen abhängig vom Lernstand Wiederholungsabstände von 4 Stunden bis 14 Tagen.
- Schwache Begriffe kommen deutlich früher zurück; sicher gelernte Begriffe werden mit wachsenden Abständen erneut geprüft.
- Wiederholungsplan bleibt vollständig pro Kinderprofil und Sprache getrennt.
- Minos adaptiver Lernpfad priorisiert fällige Wiederholungen automatisch und startet dafür das gezielte Mino-Training.
- Im Elternbereich wird jetzt angezeigt, wie viele Begriffe heute zur Wiederholung fällig sind.
- Review-Rangfolge berücksichtigt überfällige Begriffe stärker.
- Vier neue Tests für Wiederholungsintervalle, Fälligkeit und Sprachtrennung; Empfehlungstest erweitert.

## 1.1.0-beta.2 – Gezieltes Mino-Training

- Neues 15. Spiel **Mino-Training / Mino tekrarı** für gezielte Wiederholung.
- Wiederholungslogik priorisiert Begriffe mit Fehlern und noch unsicherem Lernstand.
- Wiederholung bleibt strikt pro Kinderprofil und Sprache getrennt.
- Lernwelten zeigen bei vorhandenen Schwachstellen einen direkten großen Wiederholungs-Knopf.
- Der adaptive Lernpfad kann jetzt gezielt Mino-Training empfehlen statt nur allgemeine Spiele.
- Veraltete Versionsanzeige im Elternbereich korrigiert.
- Drei neue Tests für Priorisierung, Sprachtrennung und vollständig gemeisterte Welten.
- Teststand: 33/33 bestanden.
- Inhaltsprüfung: 16 Welten, 278 zweisprachige Lernobjekte, 15 Spieltypen.
- Der lokale Vite-Build kann in dieser Arbeitsumgebung weiterhin nicht neu erzeugt werden, weil das vorhandene `node_modules/vite` unvollständig ist. Der Offline-Vertrag des vorhandenen Builds wird weiterhin erfolgreich geprüft.

## 0.9.0 – Adaptiver Lernpfad

- Neuer persönlicher **Mino-Lernpfad** auf der Startseite mit drei großen, direkt spielbaren Empfehlungen.
- Empfehlungen werden pro Kinderprofil und pro Sprache aus echtem Lernfortschritt berechnet.
- Welten mit vielen Fehlern werden automatisch wieder vorgeschlagen; neue und wenig gespielte Welten bleiben im Mix.
- Die Spielauswahl bevorzugt Abwechslung, damit nicht immer dasselbe Minispiel erscheint.
- Der große „Weiterspielen“-Knopf startet jetzt die sinnvollste aktuelle Empfehlung statt starr immer „Hör & Tipp“.
- Neue automatische Tests für Spielbarkeit, Abwechslung, Lernschwächen und Sprachtrennung.

## 0.8.0
- 12 kindgerechte, automatisch berechnete Mino-Medaillen ergänzt.
- Erfolge für Sterne, Lernfortschritt, Serien, Spielvielfalt, Welten und Aquarium-Schätze.
- Neue responsive Medaillen-Sammlung direkt im Aquarium; pro Kinderprofil vollständig getrennt.
- Keine neue sensible Datenspeicherung: Medaillen werden aus dem vorhandenen Lernfortschritt abgeleitet.


## 0.7.0 – Immersive World Hub

- Jede Lernwelt startet jetzt in einer großen, interaktiven Abenteuerszene statt direkt in einer Kartenliste.
- Sechs sehr große Objekte können direkt angetippt, gesprochen und visuell als entdeckt markiert werden.
- Neue drei Modi pro Welt: Abenteuer, Spiele und Entdecken.
- Großer direkter Einstieg in die Entdeckerwelt aus jeder Lernwelt.
- Welten bekommen unterschiedliche Atmosphären und mobile Vollbilddarstellung.
- Bewegungen respektieren die System-Einstellung für reduzierte Bewegung.

# MINIK 0.6.0

- Multi-child launch screen: when two or more child profiles exist, a fresh app session asks “Who is playing today?” before learning begins.
- Profile cards now show each child’s own stars, completed sessions, and learned concepts.
- Profile editing now supports both name and avatar changes.
- Expanded aquarium reward path from 7 to 13 rewards, up to 300 stars.
- Removed stale hard-coded home counters; world/game counts now follow live content.
- Parent area version label updated.
- Existing progress remains separated by child and is migrated without loss.

# 0.5.0

- Neue bildschirmfüllende **Entdeckerwelt** als 14. Spieltyp für alle Lernwelten.
- Große Szenen mit bis zu sechs frei antippbaren Lernobjekten statt reiner Karten-Quiz-Optik.
- Malen erweitert: freie Fläche + bis zu fünf Malvorlagen aus der jeweiligen Lernwelt.
- Löschen fragt bei bestehender Zeichnung nach Bestätigung; Undo korrigiert jetzt auch den Stroke-Zähler.
- Mobile Szenen und Malfläche auf große iPhone/iPad-Touchbereiche optimiert.
- Content-/Progress-Regressionstests weiterhin grün.

# 0.4.0

- Neue Malwelt mit Fingerzeichnen, 8 Farben, 3 Strichstärken, Radierer, Undo und Löschen.
- Memory gegen schnelle dritte/mehrfache Taps zusätzlich synchron gesperrt.
- Rhythmus/Melodie wartet auf einen wirklich laufenden AudioContext – wichtig für iPhone/iPad Safari.
- Lernwelten und Spielobjekte massiv vergrößert; mobile Welten sind jetzt große, horizontale Szenenkarten statt kleiner Kacheln.
- Spielkarten und 2er-Auswahl nutzen deutlich mehr der sichtbaren Höhe.
- Stimmen-Ranking für hochwertige lokale Apple-/Systemstimmen verbessert.
- Kinderprofile aus 0.3.1 bleiben vollständig erhalten.

# Changelog

## 0.3.0 — 2026-09-09

### Release 0.2 vollständig integriert

- Sechs getrennte Kernspiele: Hören, Memory, echtes Pointer-Zuordnen mit Tippalternative, Sortieren, Zählen und synthetisierte Alltagsgeräusche.
- Gemeinsame Spielsteuerung für Runden, Pause, Wiederholung, Hilfen und Belohnungen.

### Release 0.3 vollständig integriert

- 16 Welten und 278 vollständige DE/TR-Lernobjekte statt sechs Tierbegriffen.
- Lokale, lizenzierte SVG-Assetpipeline und versioniertes Contentmanifest.
- Foto-Variantenmodell mit Herkunftsdaten; sechs KI-generierte Erwachsenen-Gefühlsmotive.
- Neuer eigener Mino und große responsive App-Oberfläche.

### Vorgezogene Erweiterungen

- Sechs zusätzliche Spiele: Puzzle, Schatten, Merkspiel, Muster, Zahlenpfade und Musikfolge.
- Mehrstufige Mino-Hilfe, anpassbare Schwierigkeit, eigenständige DE/TR-Lernstatistik.
- XP, Level, Sterne, Tagesmission, sieben Schätze und Aquariumgestaltung.
- Elternbereich mit optionaler PIN, Sprach- und Audioeinstellungen, schwierigen Begriffen und Sitzungen.
- Sofortige lokale Speicherung pro Antwort; alte Sterne und Sprache werden übernommen.
- Produktions-Service-Worker mit komplettem kompaktem Kern und Cache-Trennung pro Installationspfad.
- GitHub Actions, 21 Content-/Fortschrittstests und Offline-Buildprüfung für Root- und Repository-Pfade.
- Browserprüfungen aller zwölf Mechaniken; responsive Prüfung bei 320, 393 und 768 Pixeln sowie Desktop.

### Behobene Probleme

- Welten öffnen nicht mehr alle dasselbe Tierquiz.
- Keine mehrfachen Sterne durch wiederholte Klicks; Fehlversuche geben keine Sterne.
- Hilfestellung wird nicht als selbstständige Begriffsbeherrschung gezählt.
- Wiederholte Fehlversuche senken die nächste Schwierigkeitsstufe auch ohne anschließende richtige Antwort.
- Puzzle wird nur für tatsächlich geeignete Bildwelten angeboten.
- Unsichtbare Antwortduplikate durch gleiche Bildmotive werden vermieden.
- Tablet-Symbolnavigation erhält zugängliche Namen; Pausendialog sperrt Hintergrundbedienung.

## 0.1 — übernommener Ausgangsstand

React/Vite-Starter, sechs Tierbegriffe, eine Auswahlrunde, einfache Sterne und System-TTS.

## 0.3.1 – Multi-child profiles
- Added up to 8 separate child profiles with name and avatar.
- Each profile has isolated stars, XP, streaks, mastery, sessions, rewards, aquarium state and settings.
- Existing 0.3 progress is automatically migrated into the first profile so nothing is lost.
- Added fast profile switching in the top bar and sidebar.
- Added bilingual profile management (DE/TR), rename and protected delete (at least one profile remains).
- Home greeting now uses the active child's name.

## 1.0.0-beta.1 — Lernstand pro Begriff

- Neuer zentraler Mastery-Helper trennt jeden Begriff in Neu, Lernen, Noch üben und Sicher gelernt.
- Lernstand bleibt strikt nach Kinderprofil und Sprache getrennt.
- Jede Lernwelt zeigt nun einen echten Prozent-Fortschrittsbalken.
- Entdecken-Ansicht kennzeichnet Begriffe sichtbar mit ihrem Lernstatus.
- Große Abenteuerszene markiert bereits sicher gelernte und übungspflichtige Begriffe direkt am Objekt.
- Drei neue Regressionstests prüfen Statuslogik, Sprachtrennung und Welt-Fortschritt.
