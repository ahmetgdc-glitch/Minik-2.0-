export const APP_VERSION = "1.8.0-beta.9";
export const APP_VERSION_LABEL = "MINIK 1.8 Beta 9";
