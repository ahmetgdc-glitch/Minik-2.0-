export async function registerOffline() {
  if (!import.meta.env.PROD || !("serviceWorker" in navigator)) return;
  try {
    const url = new URL(
      "sw.js",
      new URL(import.meta.env.BASE_URL, window.location.href),
    );
    await navigator.serviceWorker.register(url, {
      scope: new URL("./", url).pathname,
    });
  } catch {
    // Offline installation is optional; storage and online play still function.
  }
}
