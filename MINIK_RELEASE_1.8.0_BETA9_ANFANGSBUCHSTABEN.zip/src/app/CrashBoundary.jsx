import React from "react";
import { Home, RotateCcw } from "lucide-react";
import { Mino } from "../components/Visual.jsx";

export default class CrashBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { failed: false };
  }
  static getDerivedStateFromError() {
    return { failed: true };
  }
  componentDidCatch(error) {
    try {
      console.error("MINIK recovered from a screen error", error);
    } catch {}
  }
  render() {
    if (!this.state.failed) return this.props.children;
    return (
      <main className="crash-recovery" role="alert">
        <Mino />
        <h1>MINIK braucht kurz Hilfe</h1>
        <p>Dein Lernfortschritt bleibt gespeichert. Öffne die Startseite oder lade MINIK neu.</p>
        <div>
          <button className="primary" onClick={() => { window.location.hash = "#/"; this.setState({ failed: false }); }}>
            <Home size={20} /> Startseite
          </button>
          <button className="secondary" onClick={() => window.location.reload()}>
            <RotateCcw size={20} /> Neu laden
          </button>
        </div>
      </main>
    );
  }
}
