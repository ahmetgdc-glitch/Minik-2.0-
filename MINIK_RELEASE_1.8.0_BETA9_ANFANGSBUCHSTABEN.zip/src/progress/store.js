import { useSyncExternalStore } from "react";
import { STORAGE_KEY, freshState, migrate, normalizeState, reduceProgress } from "./model.js";
import { createBackupPayload, parseBackupPayload } from "./backup.js";

const FAMILY_KEY = "minik_profiles_v1";
const ACTIVE_KEY = "minik_active_profile_v1";
const MAX_PROFILES = 8;
const AVATARS = ["🐠","🦁","🐼","🐰","🦊","🐸","🐯","🐨","🦄","🚀","🌈","⭐"];
let storage;
try { storage = window.localStorage; } catch {}
let storageFailed = false;
const listeners = new Set();

const cleanName = (name, fallback = "Kind") => String(name || "").trim().slice(0, 18) || fallback;
const makeId = () => `p_${Date.now().toString(36)}_${Math.random().toString(36).slice(2,7)}`;
const publicProfile = (p) => {
  const progress = normalizeState(p?.progress);
  return {
    id: p.id,
    name: p.name,
    avatar: p.avatar,
    createdAt: p.createdAt,
    stars: progress.stars,
    xp: progress.xp,
    sessions: progress.sessions.filter((x) => x.completed).length,
    learned: Object.values(progress.mastery).filter((x) => (x?.independent || 0) >= 3).length,
  };
};

function loadFamily() {
  try {
    const raw = JSON.parse(storage?.getItem(FAMILY_KEY) || "null");
    if (raw?.version === 1 && Array.isArray(raw.profiles) && raw.profiles.length) {
      const profiles = raw.profiles.slice(0, MAX_PROFILES).map((p,i) => ({
        id: String(p.id || makeId()),
        name: cleanName(p.name, `Kind ${i+1}`),
        avatar: AVATARS.includes(p.avatar) ? p.avatar : AVATARS[i % AVATARS.length],
        createdAt: Number(p.createdAt) || Date.now(),
        progress: normalizeState(p.progress),
      }));
      const requested = storage?.getItem(ACTIVE_KEY);
      return { profiles, activeId: profiles.some(p=>p.id===requested) ? requested : profiles[0].id };
    }
  } catch {}
  // First profile inherits the existing MINIK progress so no child loses stars or learning history.
  const legacy = migrate(storage);
  const first = { id: makeId(), name: "Kind 1", avatar: "🐠", createdAt: Date.now(), progress: legacy };
  return { profiles:[first], activeId:first.id };
}

let family = loadFamily();
let state = family.profiles.find(p=>p.id===family.activeId)?.progress || freshState();
let snapshot;

function rebuildSnapshot(){
  snapshot = {
    ...state,
    profiles: family.profiles.map(publicProfile),
    activeProfileId: family.activeId,
    activeProfile: publicProfile(family.profiles.find(p=>p.id===family.activeId) || family.profiles[0]),
    maxProfiles: MAX_PROFILES,
    profileAvatars: AVATARS,
  };
}
rebuildSnapshot();

function saveFamily(){
  try {
    const active = family.profiles.find(p=>p.id===family.activeId);
    if (active) active.progress = normalizeState(state);
    storage?.setItem(FAMILY_KEY, JSON.stringify({version:1, profiles:family.profiles}));
    storage?.setItem(ACTIVE_KEY, family.activeId);
    // Keep the old key synchronized with the active child for backwards compatibility.
    storage?.setItem(STORAGE_KEY, JSON.stringify(normalizeState(state)));
    storageFailed = !storage;
  } catch { storageFailed = true; }
}
function emit(){ rebuildSnapshot(); listeners.forEach(fn=>fn()); }

export const getState = () => snapshot;
export const getStorageFailure = () => storageFailed;
export function dispatch(action){ state = reduceProgress(state, action); saveFamily(); emit(); return snapshot; }
export const setSettings = (patch) => dispatch({type:"settings",patch});

export function switchProfile(id){
  const next = family.profiles.find(p=>p.id===id);
  if (!next || id===family.activeId) return snapshot;
  const current = family.profiles.find(p=>p.id===family.activeId);
  if (current) current.progress = normalizeState(state);
  family.activeId = id;
  state = normalizeState(next.progress);
  saveFamily(); emit(); return snapshot;
}

export function addProfile({name, avatar} = {}){
  if (family.profiles.length >= MAX_PROFILES) return null;
  const currentSettings = state.settings;
  const progress = freshState();
  progress.settings = {
    ...progress.settings,
    lang: currentSettings.lang,
    audio: currentSettings.audio,
    sfx: currentSettings.sfx,
    rate: currentSettings.rate,
    pitch: currentSettings.pitch,
    voices: {...currentSettings.voices},
  };
  const p = {
    id: makeId(),
    name: cleanName(name, `Kind ${family.profiles.length+1}`),
    avatar: AVATARS.includes(avatar) ? avatar : AVATARS[family.profiles.length % AVATARS.length],
    createdAt: Date.now(), progress,
  };
  const current = family.profiles.find(x=>x.id===family.activeId);
  if (current) current.progress = normalizeState(state);
  family.profiles.push(p); family.activeId = p.id; state = progress;
  saveFamily(); emit(); return p.id;
}

export function updateProfile(id, patch={}){
  const p = family.profiles.find(x=>x.id===id); if(!p) return;
  if (patch.name !== undefined) p.name = cleanName(patch.name, p.name);
  if (patch.avatar !== undefined && AVATARS.includes(patch.avatar)) p.avatar = patch.avatar;
  saveFamily(); emit();
}

export function deleteProfile(id){
  if (family.profiles.length <= 1) return false;
  const idx = family.profiles.findIndex(p=>p.id===id); if(idx<0) return false;
  const deletingActive = family.activeId===id;
  family.profiles.splice(idx,1);
  if(deletingActive){
    const next = family.profiles[Math.min(idx, family.profiles.length-1)];
    family.activeId = next.id; state = normalizeState(next.progress);
  }
  saveFamily(); emit(); return true;
}


export function createFamilyBackup(){
  const active = family.profiles.find(p=>p.id===family.activeId);
  if (active) active.progress = normalizeState(state);
  return createBackupPayload(family.profiles, family.activeId);
}

export function restoreFamilyBackup(payload){
  const restored = parseBackupPayload(payload);
  family = { profiles: restored.profiles.map((p,i)=>({ ...p, avatar: AVATARS.includes(p.avatar) ? p.avatar : AVATARS[i % AVATARS.length] })), activeId: restored.activeId };
  state = normalizeState(family.profiles.find(p=>p.id===family.activeId)?.progress);
  saveFamily(); emit(); return snapshot;
}

export function useProgress(){
  return useSyncExternalStore(
    fn=>{listeners.add(fn); return ()=>listeners.delete(fn)},
    getState,
    getState,
  );
}

if (typeof window !== "undefined") window.addEventListener("storage", e=>{
  if ([FAMILY_KEY,ACTIVE_KEY].includes(e.key)) {
    family = loadFamily(); state = normalizeState(family.profiles.find(p=>p.id===family.activeId)?.progress); emit();
  }
});
