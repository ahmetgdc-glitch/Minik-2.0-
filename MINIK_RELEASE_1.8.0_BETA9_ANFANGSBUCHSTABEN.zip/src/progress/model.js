export const STORAGE_KEY = "minik_progress_v3";
export const defaultSettings = {
  lang: "de",
  audio: true,
  sfx: true,
  autoHelp: true,
  photos: true,
  adaptive: true,
  options: 2,
  rate: 0.9,
  pitch: 1,
  voices: { de: "", tr: "" },
  pin: "",
  reducedMotion: false,
};
export function freshState() {
  return {
    version: 3,
    settings: { ...defaultSettings, voices: { de: "", tr: "" } },
    stars: 0,
    xp: 0,
    streak: 0,
    bestStreak: 0,
    answers: 0,
    correct: 0,
    worlds: {},
    mastery: {},
    history: [],
    sessions: [],
    events: [],
    inventory: [],
    equipped: [],
    daily: { date: "", correct: 0 },
    lastWorld: "animals",
  };
}
const count = (x) =>
  Math.max(0, Number.isFinite(Number(x)) ? Math.floor(Number(x)) : 0);
export function normalizeState(raw) {
  const s = freshState();
  if (!raw || typeof raw !== "object" || raw.version !== 3) return s;
  for (const key of [
    "stars",
    "xp",
    "streak",
    "bestStreak",
    "answers",
    "correct",
  ])
    s[key] = count(raw[key]);
  const settings = { ...defaultSettings, ...raw.settings };
  settings.lang = ["de", "tr"].includes(settings.lang) ? settings.lang : "de";
  settings.options = [2, 4, 6].includes(Number(settings.options))
    ? Number(settings.options)
    : 2;
  settings.rate = Math.min(1.15, Math.max(0.65, Number(settings.rate) || 0.9));
  settings.pitch = Math.min(1.3, Math.max(0.8, Number(settings.pitch) || 1));
  settings.voices = { ...defaultSettings.voices, ...settings.voices };
  settings.pin = String(settings.pin || "")
    .replace(/\D/g, "")
    .slice(0, 4);
  s.settings = settings;
  for (const key of ["worlds", "mastery"])
    s[key] =
      raw[key] && typeof raw[key] === "object" && !Array.isArray(raw[key])
        ? raw[key]
        : {};
  for (const key of ["history", "sessions", "events", "inventory", "equipped"])
    s[key] = Array.isArray(raw[key]) ? raw[key] : [];
  s.history = s.history.slice(-500);
  s.sessions = s.sessions.slice(-100);
  s.events = s.events.slice(-600);
  s.daily = raw.daily?.date
    ? { date: String(raw.daily.date), correct: count(raw.daily.correct) }
    : s.daily;
  s.lastWorld = typeof raw.lastWorld === "string" ? raw.lastWorld : "animals";
  return s;
}
export function migrate(storage) {
  try {
    const current = storage?.getItem(STORAGE_KEY);
    if (current) return normalizeState(JSON.parse(current));
    const s = freshState();
    const old = JSON.parse(storage?.getItem("minik_state_v2") || "null");
    s.stars = count(old?.stars ?? storage?.getItem("minik_stars"));
    s.xp = s.stars * 10;
    s.streak = count(old?.streak ?? storage?.getItem("minik_streak"));
    s.bestStreak = s.streak;
    const lang = old?.settings?.lang || storage?.getItem("minik_lang");
    if (["de", "tr"].includes(lang)) s.settings.lang = lang;
    if (old?.settings) {
      s.settings.rate = Number(old.settings.voiceRate) || 0.9;
      s.settings.options = [2, 4, 6].includes(Number(old.settings.difficulty))
        ? Number(old.settings.difficulty)
        : 2;
    }
    return s;
  } catch {
    return freshState();
  }
}
export function localDay(date = new Date()) {
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
}
export function difficultyFor(state, worldId, lang = state.settings.lang) {
  if (!state.settings.adaptive) return state.settings.options;
  const recent = state.worlds[`${lang}:${worldId}`]?.recent || [];
  if (recent.length < 8) return 2;
  const last = recent.slice(-12),
    accuracy = last.filter(Boolean).length / last.length;
  return accuracy >= 0.9 && last.length >= 12 ? 6 : accuracy >= 0.75 ? 4 : 2;
}
export function reduceProgress(state, action) {
  if (action.type === "settings")
    return {
      ...state,
      settings: {
        ...state.settings,
        ...action.patch,
        voices: { ...state.settings.voices, ...action.patch.voices },
      },
    };
  if (action.type === "answer") {
    if (state.events.includes(action.eventId)) return state;
    const correct = !!action.correct,
      clean = correct && !action.assisted && !action.hadErrors;
    const s = {
      ...state,
      events: [...state.events, action.eventId].slice(-600),
      worlds: { ...state.worlds },
      mastery: { ...state.mastery },
      answers: state.answers + 1,
      correct: state.correct + Number(correct),
      stars: state.stars + Number(correct),
      xp: state.xp + (correct ? 10 : 0),
      streak: correct ? state.streak + 1 : 0,
      lastWorld: action.worldId,
    };
    s.bestStreak = Math.max(s.bestStreak, s.streak);
    const today = action.day || localDay();
    s.daily = {
      date: today,
      correct:
        (state.daily.date === today ? state.daily.correct : 0) +
        Number(correct),
    };
    const key = `${action.lang}:${action.worldId}`,
      w = state.worlds[key] || {
        answers: 0,
        correct: 0,
        recent: [],
        sessions: 0,
      };
    s.worlds[key] = {
      ...w,
      answers: w.answers + 1,
      correct: w.correct + Number(correct),
      recent: [...w.recent, clean].slice(-12),
    };
    for (const id of [...new Set(action.itemIds || [])]) {
      const mk = `${action.lang}:${id}`,
        m = state.mastery[mk] || { correct: 0, wrong: 0, independent: 0 };
      s.mastery[mk] = {
        ...m,
        correct: m.correct + Number(correct),
        wrong: m.wrong + Number(!correct),
        independent: m.independent + Number(clean),
        lastSeen: action.at,
      };
    }
    s.history = [
      ...state.history,
      {
        at: action.at,
        worldId: action.worldId,
        gameId: action.gameId,
        lang: action.lang,
        correct,
        assisted: !!action.assisted,
        clean,
        itemIds: action.itemIds || [],
      },
    ].slice(-500);
    return s;
  }
  if (action.type === "session") {
    if (state.sessions.some((s) => s.id === action.session.id)) return state;
    const session = action.session,
      key = `${session.lang}:${session.worldId}`,
      w = state.worlds[key] || {
        answers: 0,
        correct: 0,
        recent: [],
        sessions: 0,
      };
    return {
      ...state,
      sessions: [...state.sessions, session].slice(-100),
      worlds: {
        ...state.worlds,
        [key]: {
          ...w,
          sessions: (w.sessions || 0) + Number(session.completed),
        },
      },
    };
  }
  if (action.type === "claim") {
    if (
      state.inventory.includes(action.reward.id) ||
      state.stars < action.reward.stars
    )
      return state;
    return {
      ...state,
      inventory: [...state.inventory, action.reward.id],
      equipped: [...state.equipped, action.reward.id],
    };
  }
  if (action.type === "equip") {
    if (!state.inventory.includes(action.id)) return state;
    return {
      ...state,
      equipped: state.equipped.includes(action.id)
        ? state.equipped.filter((x) => x !== action.id)
        : [...state.equipped, action.id],
    };
  }
  if (action.type === "reset")
    return { ...freshState(), settings: state.settings };
  return state;
}
