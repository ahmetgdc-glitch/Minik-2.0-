import { normalizeState } from "./model.js";

export const BACKUP_FORMAT = "minik-family-backup";
export const BACKUP_VERSION = 1;
export const BACKUP_MAX_PROFILES = 8;

const cleanName = (value, fallback) =>
  String(value || "").trim().slice(0, 18) || fallback;

export function createBackupPayload(profiles, activeId) {
  const safe = (profiles || []).slice(0, BACKUP_MAX_PROFILES).map((profile, index) => ({
    id: String(profile.id || `profile-${index + 1}`),
    name: cleanName(profile.name, `Kind ${index + 1}`),
    avatar: String(profile.avatar || "🐠"),
    createdAt: Number(profile.createdAt) || Date.now(),
    progress: normalizeState(profile.progress),
  }));
  return {
    format: BACKUP_FORMAT,
    version: BACKUP_VERSION,
    exportedAt: Date.now(),
    activeId: safe.some((profile) => profile.id === activeId) ? activeId : safe[0]?.id || "",
    profiles: safe,
  };
}

export function parseBackupPayload(input) {
  let raw = input;
  if (typeof input === "string") {
    try { raw = JSON.parse(input); } catch { throw new Error("invalid-json"); }
  }
  if (!raw || typeof raw !== "object" || raw.format !== BACKUP_FORMAT || raw.version !== BACKUP_VERSION)
    throw new Error("invalid-format");
  if (!Array.isArray(raw.profiles) || !raw.profiles.length)
    throw new Error("no-profiles");
  if (raw.profiles.length > BACKUP_MAX_PROFILES)
    throw new Error("too-many-profiles");

  const ids = new Set();
  const profiles = raw.profiles.map((profile, index) => {
    if (!profile || typeof profile !== "object") throw new Error("invalid-profile");
    const id = String(profile.id || "").trim();
    if (!id || ids.has(id)) throw new Error("invalid-profile-id");
    ids.add(id);
    return {
      id,
      name: cleanName(profile.name, `Kind ${index + 1}`),
      avatar: String(profile.avatar || "🐠"),
      createdAt: Number(profile.createdAt) || Date.now(),
      progress: normalizeState(profile.progress),
    };
  });
  return {
    profiles,
    activeId: ids.has(String(raw.activeId || "")) ? String(raw.activeId) : profiles[0].id,
  };
}
