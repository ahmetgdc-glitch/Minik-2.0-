import React, { useEffect, useState } from "react";
import Visual from "../components/Visual.jsx";
import { choicesFor, sample } from "../utils/random.js";
export function useSelection(items, difficulty) {
  const [target] = useState(() => sample(items, 1)[0]);
  const [options] = useState(() => choicesFor(target, items, difficulty));
  return { target, options };
}
export function useLesson(onReady, text, repeat, ids, help) {
  useEffect(() => {
    onReady({ text, repeat, ids, help });
  }, [text, onReady]);
}
export function OptionGrid({
  options,
  target,
  hint,
  lang,
  settings,
  onPick,
  hiddenLabels = false,
}) {
  const wrong = options.find((x) => x.id !== target?.id);
  return (
    <div className={`answer-grid options-${options.length}`}>
      {options.map((item) => (
        <button
          key={item.id}
          className={`answer-card ${hint >= 2 && item.id === target?.id ? "hint-target" : ""} ${hint >= 2 && options.length > 2 && item.id === wrong?.id ? "quiet-option" : ""}`}
          onClick={() => onPick(item)}
          aria-label={item.labels[lang]}
        >
          <Visual item={item} lang={lang} photos={settings.photos} />
          {!hiddenLabels && <b>{item.labels[lang]}</b>}
        </button>
      ))}
    </div>
  );
}
