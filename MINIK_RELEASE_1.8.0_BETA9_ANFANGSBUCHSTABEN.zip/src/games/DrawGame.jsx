import React, { useEffect, useMemo, useRef, useState } from "react";
import { Eraser, RotateCcw, Trash2, Check, Palette, Image as ImageIcon, Sparkles } from "lucide-react";
import Visual from "../components/Visual.jsx";
import { useLesson } from "./shared.jsx";

const COLORS = ["#203750", "#ef5b5b", "#ff9d42", "#ffd43b", "#4bb978", "#3b92c9", "#855fd1", "#ef7eb2"];
const SIZES = [8, 16, 28];

export default function DrawGame({ items = [], lang, hint, paused, onReady, onSolve }) {
  const canvasRef = useRef(null);
  const wrapRef = useRef(null);
  const drawing = useRef(false);
  const last = useRef(null);
  const history = useRef([]);
  const [color, setColor] = useState(COLORS[1]);
  const [size, setSize] = useState(SIZES[1]);
  const [eraser, setEraser] = useState(false);
  const [strokes, setStrokes] = useState(0);
  const templates = useMemo(() => [null, ...items.slice(0, 5)], [items]);
  const [templateId, setTemplateId] = useState(null);
  const template = templates.find(x => x?.id === templateId) || null;

  const text = lang === "tr" ? "Büyük tuvalde boya, çiz ve hayal et." : "Male, zeichne und erfinde etwas auf der großen Fläche.";
  useLesson(onReady, text, () => {}, [template?.id || "creative.draw"], lang === "tr" ? "Bir renk seç. İstersen bir boyama resmi seç." : "Wähle eine Farbe. Du kannst auch eine Malvorlage wählen.");

  function fitCanvas() {
    const c = canvasRef.current, w = wrapRef.current;
    if (!c || !w) return;
    const rect = w.getBoundingClientRect();
    const dpr = Math.max(1, Math.min(2, window.devicePixelRatio || 1));
    const old = c.width && c.height ? c.toDataURL() : null;
    c.width = Math.round(rect.width * dpr);
    c.height = Math.round(rect.height * dpr);
    c.style.width = `${rect.width}px`;
    c.style.height = `${rect.height}px`;
    const ctx = c.getContext("2d");
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.lineCap = "round";
    ctx.lineJoin = "round";
    if (old) {
      const img = new Image();
      img.onload = () => ctx.drawImage(img, 0, 0, rect.width, rect.height);
      img.src = old;
    }
  }
  useEffect(() => {
    fitCanvas();
    const ro = new ResizeObserver(fitCanvas);
    if (wrapRef.current) ro.observe(wrapRef.current);
    return () => ro.disconnect();
  }, []);

  function point(e) {
    const r = canvasRef.current.getBoundingClientRect();
    return { x: e.clientX - r.left, y: e.clientY - r.top };
  }
  function save() {
    const c = canvasRef.current;
    if (!c) return;
    history.current = [...history.current.slice(-14), c.toDataURL()];
  }
  function start(e) {
    if (paused) return;
    e.preventDefault();
    e.currentTarget.setPointerCapture?.(e.pointerId);
    save();
    drawing.current = true;
    last.current = point(e);
  }
  function move(e) {
    if (!drawing.current || paused) return;
    e.preventDefault();
    const c = canvasRef.current, ctx = c.getContext("2d"), p = point(e), a = last.current;
    ctx.globalCompositeOperation = eraser ? "destination-out" : "source-over";
    ctx.strokeStyle = color;
    ctx.lineWidth = size;
    ctx.beginPath();
    ctx.moveTo(a.x, a.y);
    ctx.lineTo(p.x, p.y);
    ctx.stroke();
    last.current = p;
  }
  function end() {
    if (drawing.current) setStrokes(s => s + 1);
    drawing.current = false;
    last.current = null;
  }
  function clear() {
    if (strokes > 0 && !window.confirm(lang === "tr" ? "Resmi tamamen silelim mi?" : "Das ganze Bild löschen?")) return;
    save();
    const c = canvasRef.current, ctx = c.getContext("2d");
    ctx.clearRect(0, 0, c.width, c.height);
    setStrokes(0);
  }
  function undo() {
    const src = history.current.pop();
    if (!src) return;
    const c = canvasRef.current, ctx = c.getContext("2d"), r = c.getBoundingClientRect();
    ctx.clearRect(0, 0, c.width, c.height);
    const img = new Image();
    img.onload = () => ctx.drawImage(img, 0, 0, r.width, r.height);
    img.src = src;
    setStrokes(s => Math.max(0, s - 1));
  }

  return <div className="draw-stage">
    <div className="draw-template-strip" aria-label={lang === "tr" ? "Boyama resimleri" : "Malvorlagen"}>
      {templates.map((item, i) => <button key={item?.id || "free"} className={(item?.id || null) === templateId ? "active" : ""} onClick={() => setTemplateId(item?.id || null)}>
        {item ? <Visual item={item} lang={lang} photos={false}/> : <><Sparkles size={28}/><b>{lang === "tr" ? "Serbest" : "Frei"}</b></>}
      </button>)}
    </div>
    <div className="draw-toolbar" aria-label={lang === "tr" ? "Boyama araçları" : "Malwerkzeuge"}>
      <span className="draw-tool-label"><Palette size={20}/>{lang === "tr" ? "Renk" : "Farbe"}</span>
      <div className="draw-colors">{COLORS.map(c => <button key={c} aria-label={c} className={color === c && !eraser ? "active" : ""} style={{"--c": c}} onClick={() => {setColor(c); setEraser(false)}} />)}</div>
      <div className="draw-sizes">{SIZES.map(s => <button key={s} className={size === s ? "active" : ""} onClick={() => setSize(s)}><i style={{width: s, height: s}}/></button>)}</div>
      <button className={eraser ? "tool-button active" : "tool-button"} onClick={() => setEraser(e => !e)} aria-label={lang === "tr" ? "Silgi" : "Radierer"}><Eraser size={21}/></button>
      <button className="tool-button" onClick={undo} aria-label={lang === "tr" ? "Geri al" : "Rückgängig"}><RotateCcw size={21}/></button>
      <button className="tool-button" onClick={clear} aria-label={lang === "tr" ? "Sil" : "Löschen"}><Trash2 size={21}/></button>
    </div>
    <div className={`draw-canvas-wrap ${hint >= 2 ? "hint-frame" : ""}`} ref={wrapRef}>
      <div className={`draw-template ${template ? "has-item" : "free"}`} aria-hidden="true">
        {template ? <Visual item={template} lang={lang} photos={false}/> : <ImageIcon size={110}/>} 
      </div>
      <canvas ref={canvasRef} onPointerDown={start} onPointerMove={move} onPointerUp={end} onPointerCancel={end} onPointerLeave={end}/>
    </div>
    <button className="primary draw-done" disabled={strokes < 3} onClick={() => onSolve([template?.id || "creative.draw"])}><Check size={22}/>{lang === "tr" ? "Resmim hazır" : "Mein Bild ist fertig"}</button>
  </div>;
}
