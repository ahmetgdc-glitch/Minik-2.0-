import React, {
  useState,
  useEffect,
  useCallback,
  useRef,
  useMemo,
} from "react";
import {
  ArrowLeft,
  Pause,
  Play,
  Volume2,
  Home,
  RotateCcw,
  Star,
  ArrowRight,
} from "lucide-react";
import { useProgress, dispatch } from "../progress/store.js";
import { difficultyFor } from "../progress/model.js";
import { gameById } from "./registry.js";
import { worldById, uniqueVisuals } from "../data/content.js";
import { speak, stopSpeech } from "../audio/voice.js";
import { playSound, stopSounds, unlockAudio } from "../audio/sounds.js";
import FishGuide from "../components/FishGuide.jsx";
import { Mino, Art } from "../components/Visual.jsx";
import { recommendedActivities } from "../learning/recommendations.js";
import ListenGame from "./ListenGame.jsx";
import MemoryGame from "./MemoryGame.jsx";
import MatchGame from "./MatchGame.jsx";
import SortGame from "./SortGame.jsx";
import CountGame from "./CountGame.jsx";
import SoundsGame from "./SoundsGame.jsx";
import PuzzleGame from "./PuzzleGame.jsx";
import ShadowGame from "./ShadowGame.jsx";
import MissingGame from "./MissingGame.jsx";
import PatternGame from "./PatternGame.jsx";
import TraceGame from "./TraceGame.jsx";
import RhythmGame from "./RhythmGame.jsx";
import DrawGame from "./DrawGame.jsx";
import ExploreGame from "./ExploreGame.jsx";
import ReviewGame from "./ReviewGame.jsx";
import StoryGame from "./StoryGame.jsx";
import InitialLetterGame from "./InitialLetterGame.jsx";
const components = {
  initialletter: InitialLetterGame,
  story: StoryGame,
  review: ReviewGame,
  explore: ExploreGame,
  draw: DrawGame,
  listen: ListenGame,
  memory: MemoryGame,
  match: MatchGame,
  sort: SortGame,
  count: CountGame,
  sounds: SoundsGame,
  puzzle: PuzzleGame,
  shadow: ShadowGame,
  missing: MissingGame,
  pattern: PatternGame,
  trace: TraceGame,
  lettertrace: TraceGame,
  rhythm: RhythmGame,
};
const praise = {
  de: [
    "Wunderbar!",
    "Das hast du toll gemacht!",
    "Gefunden!",
    "Super, weiter so!",
    "Richtig gut!",
  ],
  tr: ["Harika!", "Çok güzel yaptın!", "Buldun!", "Aferin sana!", "Çok iyi!"],
};
export default function GameSession({ gameId, worldId, onNavigate }) {
  const progress = useProgress(),
    settings = progress.settings,
    lang = settings.lang,
    spec = gameById[gameId],
    world = worldById[worldId];
  const [difficulty] = useState(() => difficultyFor(progress, worldId)),
    [round, setRound] = useState(0),
    [phase, setPhase] = useState("active"),
    [paused, setPaused] = useState(false),
    [hint, setHint] = useState(0),
    [lesson, setLesson] = useState({ text: "", ids: [] }),
    [message, setMessage] = useState(""),
    [activity, setActivity] = useState(0),
    [earned, setEarned] = useState(0);
  const locked = useRef(false),
    mistakes = useRef(0),
    attempt = useRef(0),
    earnedRef = useRef(0),
    playedRef = useRef(0),
    saved = useRef(false),
    hintRef = useRef(0),
    activeSeconds = useRef(0);
  const [sessionId] = useState(
      () => `minik-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
    ),
    started = useRef(Date.now());
  const items = useMemo(() => uniqueVisuals(world?.items || []), [world]);
  const Component = components[gameId];
  const nextActivity = useMemo(() => {
    const choices = recommendedActivities(progress, lang, 3);
    return choices.find(({ world: w, game: g }) => w.id !== worldId || g.id !== gameId) || choices[0] || null;
  }, [progress, lang, worldId, gameId]);
  const saveSession = useCallback(
    (completed) => {
      if (saved.current || !playedRef.current) return;
      saved.current = true;
      dispatch({
        type: "session",
        session: {
          id: sessionId,
          worldId,
          gameId,
          lang,
          started: started.current,
          ended: Date.now(),
          seconds: activeSeconds.current,
          rounds: earnedRef.current,
          attempts: playedRef.current,
          completed,
        },
      });
    },
    [sessionId, worldId, gameId, lang],
  );
  useEffect(
    () => () => {
      stopSpeech();
      stopSounds();
      saveSession(false);
    },
    [saveSession],
  );
  useEffect(() => {
    const visibility = () => {
      if (document.hidden) setPaused(true);
    };
    document.addEventListener("visibilitychange", visibility);
    return () => document.removeEventListener("visibilitychange", visibility);
  }, []);
  useEffect(() => {
    if (paused || phase === "done") {
      stopSpeech();
      stopSounds();
      return;
    }
    const t = setInterval(() => activeSeconds.current++, 1000);
    return () => clearInterval(t);
  }, [paused, phase]);
  useEffect(() => {
    hintRef.current = hint;
  }, [hint]);
  const ready = useCallback((info) => {
    setLesson(info);
  }, []);
  useEffect(() => {
    if (!lesson.text || paused || phase !== "active" || !settings.audio) return;
    const t = setTimeout(() => lesson.repeat?.(), 200);
    return () => clearTimeout(t);
  }, [lesson, paused]);
  useEffect(() => {
    if (paused || phase !== "active" || !settings.autoHelp) return;
    const move = setTimeout(() => setHint((h) => Math.max(h, 1)), 6000);
    const help = setTimeout(() => {
      setMessage(
        lang === "tr"
          ? "Yardım ister misin? Bana dokun."
          : "Möchtest du Hilfe? Tippe auf mich.",
      );
      if (settings.audio)
        speak(
          lang === "tr" ? "Sana yardım edeyim mi?" : "Soll ich dir helfen?",
          lang,
          settings,
        );
    }, 11000);
    return () => {
      clearTimeout(move);
      clearTimeout(help);
    };
  }, [round, activity, paused, phase, settings.autoHelp, lang]);
  function record(correct, ids) {
    const id = `${sessionId}:${round}:${++attempt.current}`;
    playedRef.current++;
    dispatch({
      type: "answer",
      eventId: id,
      worldId,
      gameId,
      lang,
      itemIds: ids,
      correct,
      assisted: hintRef.current >= 2,
      hadErrors: mistakes.current > 0,
      at: Date.now(),
    });
  }
  const wrong = useCallback(
    (ids) => {
      if (locked.current || paused) return;
      mistakes.current++;
      record(false, ids);
      setActivity((a) => a + 1);
      const text = lang === "tr" ? "Bir daha bak." : "Schau noch einmal.";
      setMessage(text);
      speak(text, lang, settings);
      if (mistakes.current >= 2) {
        setHint(2);
        hintRef.current = 2;
      }
      if (mistakes.current >= 3) {
        locked.current = true;
        setHint(3);
        hintRef.current = 3;
        setPhase("demo");
        setMessage(
          lang === "tr"
            ? "Bak, birlikte yapıyoruz."
            : "Schau, wir machen es zusammen.",
        );
        speak(lesson.help || lesson.text, lang, settings);
      }
    },
    [round, paused, lesson, lang, settings],
  );
  const solve = useCallback(
    (ids) => {
      if (locked.current || paused) return;
      locked.current = true;
      record(true, ids);
      earnedRef.current++;
      setEarned(earnedRef.current);
      setPhase("success");
      const text = praise[lang][round % praise[lang].length];
      setMessage(text);
      playSound("success", settings);
      speak(text, lang, settings);
    },
    [round, paused, lang, settings],
  );
  useEffect(() => {
    if (paused || !["success", "demo"].includes(phase)) return;
    const t = setTimeout(
      () => {
        if (round + 1 >= spec.rounds) {
          saveSession(true);
          setPhase("done");
          stopSounds();
          stopSpeech();
        } else {
          locked.current = false;
          mistakes.current = 0;
          hintRef.current = 0;
          setHint(0);
          setMessage("");
          setLesson({ text: "", ids: [] });
          setRound((r) => r + 1);
          setPhase("active");
        }
      },
      phase === "demo" ? 3800 : 1300,
    );
    return () => clearTimeout(t);
  }, [phase, paused, round, spec.rounds, saveSession]);
  function help() {
    if (phase !== "active") return;
    setHint(2);
    hintRef.current = 2;
    setActivity((a) => a + 1);
    setMessage(lesson.help || lesson.text);
    speak(lesson.help || lesson.text, lang, settings);
  }
  function exit() {
    saveSession(false);
    onNavigate(`/world/${worldId}`);
  }
  if (!world || !spec || !Component) return null;
  if (phase === "done")
    return (
      <section className="session-finish">
        <div className="finish-stars">
          <Art name="star" />
          <Art name="glowing-star" />
          <Art name="star" />
        </div>
        <Mino />
        <h1>{lang === "tr" ? "Birlikte başardık!" : "Zusammen geschafft!"}</h1>
        <p>
          {lang === "tr"
            ? "Mino ile harika çalıştın."
            : "Du hast mit Mino fleißig geübt."}
        </p>
        <div className="earned">
          <Star fill="currentColor" />
          {earned} {lang === "tr" ? "yeni yıldız" : "neue Sterne"}
        </div>
        {nextActivity && (
          <button
            className="primary next-adventure-button"
            onClick={() => {
              unlockAudio();
              onNavigate(`/play/${nextActivity.game.id}/${nextActivity.world.id}`);
            }}
          >
            <Play size={21} fill="currentColor" />
            <span>
              <small>{lang === "tr" ? "Mino’nun sıradaki önerisi" : "Minos nächster Tipp"}</small>
              {nextActivity.world.labels[lang]} · {nextActivity.game[lang]}
            </span>
            <ArrowRight size={20} />
          </button>
        )}
        <div className="finish-actions">
          <button className="secondary" onClick={() => onNavigate("/aquarium")}>
            <Art name="wrapped-gift" />
            {lang === "tr" ? "Ödüllerim" : "Meine Schätze"}
          </button>
          <button
            className="secondary"
            onClick={() => onNavigate(`/replay/${gameId}/${worldId}`)}
          >
            <RotateCcw size={20} />
            {lang === "tr" ? "Tekrar oyna" : "Noch einmal"}
          </button>
          <button className="secondary" onClick={exit}>
            <Home size={20} />
            {lang === "tr" ? "Dünyama dön" : "Zur Lernwelt"}
          </button>
        </div>
      </section>
    );
  return (
    <section className={`game-session game-${gameId} phase-${phase}`}>
      <header className="game-header" inert={paused ? true : undefined}>
        <button
          className="icon-button"
          onClick={() => setPaused(true)}
          aria-label={
            lang === "tr"
              ? "Oyunu duraklat ve çık"
              : "Spiel pausieren und verlassen"
          }
        >
          <ArrowLeft />
        </button>
        <div className="session-track">
          <span>
            {spec[lang]}{" "}
            <small>
              {round + 1} / {spec.rounds}
            </small>
          </span>
          <div className="round-track">
            {Array.from({ length: spec.rounds }, (_, i) => (
              <i
                key={i}
                className={
                  i < round ? "complete" : i === round ? "current" : ""
                }
              />
            ))}
          </div>
        </div>
        <button
          className="icon-button"
          onClick={() => setPaused(true)}
          aria-label={lang === "tr" ? "Duraklat" : "Pause"}
        >
          <Pause />
        </button>
      </header>
      <div className="game-heading" inert={paused ? true : undefined}>
        <span className="eyebrow">{world.labels[lang]}</span>
        <h1>{lesson.text}</h1>
        <button
          className="replay-audio"
          onClick={() => {
            setActivity((a) => a + 1);
            lesson.repeat?.();
            unlockAudio();
          }}
          aria-label={lang === "tr" ? "Tekrar dinle" : "Noch einmal hören"}
        >
          <Volume2 size={23} />
        </button>
      </div>
      <div
        className="game-area"
        inert={paused || phase !== "active" ? true : undefined}
        onPointerDown={() => setActivity((a) => a + 1)}
      >
        <Component
          key={`${round}-${gameId}`}
          {...{ items, world, progress, lang, settings, difficulty, round, hint, paused }}
          onReady={ready}
          onWrong={wrong}
          onSolve={solve}
        />
      </div>
      <div inert={paused ? true : undefined}>
        <FishGuide lang={lang} message={message} stage={hint} onHelp={help} />
      </div>
      {phase === "success" && (
        <div className="star-burst" aria-live="polite">
          <Art name="glowing-star" />
          <b>+1</b>
        </div>
      )}
      {paused && (
        <div className="modal-scrim">
          <div
            className="pause-dialog"
            role="dialog"
            aria-modal="true"
            aria-labelledby="pause-title"
          >
            <Mino />
            <h2 id="pause-title">
              {lang === "tr" ? "Küçük bir mola" : "Eine kleine Pause"}
            </h2>
            <p>
              {lang === "tr" ? "Mino seni bekliyor." : "Mino wartet auf dich."}
            </p>
            <button
              className="primary"
              autoFocus
              onClick={() => {
                setPaused(false);
                unlockAudio();
              }}
            >
              <Play size={22} />
              {lang === "tr" ? "Devam et" : "Weiterspielen"}
            </button>
            <button className="secondary" onClick={exit}>
              <Home size={20} />
              {lang === "tr" ? "Dünyama dön" : "Zur Lernwelt"}
            </button>
          </div>
        </div>
      )}
    </section>
  );
}
