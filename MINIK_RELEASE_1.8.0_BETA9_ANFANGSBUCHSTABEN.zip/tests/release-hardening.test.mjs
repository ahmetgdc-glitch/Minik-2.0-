import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";

const read = (p) => fs.readFileSync(new URL(`../${p}`, import.meta.url), "utf8");

test("root render is protected by crash recovery", () => {
  const main = read("src/main.jsx");
  assert.match(main, /<CrashBoundary><App \/><\/CrashBoundary>/);
});

test("game routes request wake lock without making it mandatory", () => {
  const app = read("src/App.jsx");
  const wake = read("src/app/useGameWakeLock.js");
  assert.match(app, /useGameWakeLock\(playing\)/);
  assert.match(wake, /"wakeLock" in navigator/);
  assert.match(wake, /sentinel\?\.release/);
});

test("public metadata no longer advertises stale content counts", () => {
  const html = read("index.html");
  assert.match(html, /25 Lernwelten/);
  assert.match(html, /500\+ Lernobjekte/);
  assert.doesNotMatch(html, /16 Lernwelten/);
  assert.doesNotMatch(html, /zwölf Minispiele/);
});
