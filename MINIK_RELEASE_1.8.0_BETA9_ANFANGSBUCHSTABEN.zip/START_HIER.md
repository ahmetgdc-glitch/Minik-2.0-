# MINIK 0.3.0 auf GitHub starten

Dieses Paket enthält die vollständige neue App mit zwölf Spielen und 16 Lernwelten.

## Empfohlen: vollständiges Projekt + GitHub Actions

1. ZIP entpacken.
2. Den **Inhalt des entpackten Projekts** in dein MINIK-Repository übernehmen. `package.json`, `index.html`, `src`, `public`, `scripts` und `.github` müssen im Repository-Hauptverzeichnis liegen. Vorhandene gleichnamige Projektdateien ersetzen. Das ZIP selbst nicht als einzige Datei hochladen.
3. In GitHub unter **Settings → Pages → Build and deployment → Source** die Auswahl **GitHub Actions** verwenden.
4. Die Änderung auf `main` oder `master` speichern. Unter **Actions** startet „Build, test and publish MINIK“. Alternativ den Workflow dort mit „Run workflow“ starten.
5. Wenn der Workflow erfolgreich fertig ist, die unter **Settings → Pages** angezeigte App-Adresse öffnen.

Der Workflow installiert Abhängigkeiten, führt Tests aus, baut die App und veröffentlicht ausschließlich `dist/`.

## Alternative: fertig gebaute App hochladen

Wenn du keinen Build-Workflow benutzen möchtest:

1. Im entpackten ZIP den Ordner **dist** öffnen.
2. Den **gesamten Inhalt von dist** in das Veröffentlichungsverzeichnis eines statischen GitHub-Pages-Branches übernehmen: `index.html`, `assets/`, `sw.js`, Icons, Manifest und Lizenzen gehören zusammen.
3. Bei **Settings → Pages** „Deploy from a branch“ und den entsprechenden Branch/Ordner wählen.

**Wichtig:** Die einzelne `index.html` aus dem Projektstamm ist nicht die fertig gebaute App. Auch `dist/index.html` benötigt den zugehörigen `assets`-Ordner. Wenn GitHub nur Quelltext oder eine leere Seite zeigt, diese beiden Punkte zuerst prüfen.

Am iPhone lässt sich das ZIP in der Dateien-App entpacken. Zum Übertragen der vielen Projektordner ist ein Computer wesentlich einfacher. Die fertige App selbst ist auf Handygrößen ausgelegt.

## Auf dem iPhone verwenden

Die veröffentlichte HTTPS-Adresse in Safari öffnen. Über das Teilen-Menü kann sie zum Home-Bildschirm hinzugefügt werden. Einmal mit Internet öffnen, damit die Kerndateien zwischengespeichert werden können. Danach den Offline-Betrieb auf dem Gerät ausprobieren.

DE/TR wechselt die Sprache. Unter dem Schloss im Elternbereich lässt sich eine verfügbare Stimme auswählen und anhören. Natürlichkeit und Offline-Sprechen hängen von den installierten Systemstimmen ab; MINIK kann keine nicht vorhandene Premiumstimme hinzufügen.

Sterne bleiben im jeweiligen Browser auf dem Gerät. Browserdaten löschen entfernt auch diesen Fortschritt. Safari, andere Browser und andere Geräte teilen den Fortschritt nicht automatisch.

## Für die nächste Weiterentwicklung

Zuerst `docs/HANDOFF_SUMMARY.md`, `docs/MASTER_PROMPT_FOR_WORK.md` und `docs/ROADMAP.md` lesen. Der ursprüngliche Master-Prompt bleibt als langfristiger Auftrag erhalten.
